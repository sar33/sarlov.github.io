/**
 * Admin JavaScript
 *
 * @package Puckator_Dropship_Importer
 */

(function($) {
	'use strict';

	$(document).ready(function() {
		// Search button handler
		$('#pdi-search-btn').on('click', function() {
			var keyword = $('#pdi-keyword').val() || '';
			var bySku = $('#pdi-search-sku').is(':checked') ? 1 : 0;
			
			$('#pdi-results').html('<p>' + 'Searching...' + '</p>');
			
			$.post(
				PDI.ajax,
				{
					action: 'pdi_search',
					nonce: PDI.nonce,
					keyword: keyword,
					sku_only: bySku
				},
				function(response) {
					if (response.success) {
						$('#pdi-results').html(response.data);
					} else {
						$('#pdi-results').html('<p>Error: ' + response.data + '</p>');
					}
				}
			).fail(function() {
				$('#pdi-results').html('<p>Request failed.</p>');
			});
		});

		// Allow Enter key to trigger search
		$('#pdi-keyword').on('keypress', function(e) {
			if (e.which === 13) {
				e.preventDefault();
				$('#pdi-search-btn').click();
			}
		});

		// Import selected button handler
		$(document).on('click', '#pdi-import-selected', function() {
			var items = [];
			
			$('.pdi-item:checked').each(function() {
				items.push($(this).attr('data-item'));
			});
			
			if (!items.length) {
				alert('No items selected.');
				return;
			}
			
			$('#pdi-import-status').html('<p>Importing...</p>');
			
			$.post(
				PDI.ajax,
				{
					action: 'pdi_import',
					nonce: PDI.nonce,
					items: items
				},
				function(response) {
					if (response.success) {
						var msg = 'Imported: ' + response.data.imported;
						if (response.data.errors.length) {
							msg += '<br>Errors:<br>' + response.data.errors.join('<br>');
						}
						$('#pdi-import-status').html('<div class="notice notice-success"><p>' + msg + '</p></div>');
						$('#pdi-search-btn').click();
					} else {
						$('#pdi-import-status').html('<div class="notice notice-error"><p>Error: ' + response.data.message + '</p></div>');
					}
				}
			).fail(function() {
				$('#pdi-import-status').html('<div class="notice notice-error"><p>Request failed.</p></div>');
			});
		});

		// Sync now button handler
		$('#pdi-sync-now').on('click', function() {
			var btn = $(this);
			btn.prop('disabled', true);
			$('#pdi-sync-status').html('<span class="spinner is-active" style="float:none;"></span> Syncing...');
			
			$.post(
				PDI.ajax,
				{
					action: 'pdi_manual_sync',
					nonce: PDI.nonce
				},
				function(response) {
					$('#pdi-sync-status').html(response);
					btn.prop('disabled', false);
				}
			).fail(function(xhr) {
				$('#pdi-sync-status').html('<span style="color:red;">Error: ' + xhr.responseText + '</span>');
				btn.prop('disabled', false);
			});
		});
	});
})(jQuery);