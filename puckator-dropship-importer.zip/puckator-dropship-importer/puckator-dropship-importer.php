<?php
/**
 * Plugin Name: Puckator Dropship Importer
 * Plugin URI: https://github.com/sar33/puckator-dropship-importer
 * Description: Import Puckator products into WooCommerce with secure API auth, fuzzy keyword/SKU search, dynamic pricing (price + weight-based shipping + VAT + PayPal + profit), daily sync at 06:00
 * Version: 3.5.0
 * Author: sar33
 * Author URI: https://github.com/sar33
 * Text Domain: puckator-dropship-importer
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * 
 * @package Puckator_Dropship_Importer
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin constants.
define( 'PDI_VERSION', '3.5.0' );
define( 'PDI_PLUGIN_FILE', __FILE__ );
define( 'PDI_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'PDI_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'PDI_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

// Require the main plugin class.
require_once PDI_PLUGIN_DIR . 'includes/class-pdi-plugin.php';

/**
 * Main instance of PDI_Plugin.
 *
 * @return PDI_Plugin
 */
function pdi() {
	return PDI_Plugin::instance();
}

// Initialize the plugin.
pdi();