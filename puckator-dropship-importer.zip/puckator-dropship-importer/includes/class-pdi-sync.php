<?php
/**
 * Sync Class
 *
 * @package Puckator_Dropship_Importer
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sync functionality class.
 *
 * @since 3.5.0
 */
class PDI_Sync {
	/**
	 * Sync batch size.
	 *
	 * @var int
	 */
	const SYNC_BATCH_SIZE = 400;

	/**
	 * Cron sync callback.
	 *
	 * @return void
	 */
	public static function cron_sync() {
		self::sync_products();
	}

	/**
	 * Sync products.
	 *
	 * @return array|WP_Error
	 */
	public static function sync_products() {
		if ( ! class_exists( 'WC_Product' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is required.', 'puckator-dropship-importer' ) );
		}
		
		$lock_key = 'pdi_sync_lock_' . wp_hash( home_url(), 'nonce' );
		$now      = time();
		$lock     = get_transient( $lock_key );
		
		if ( $lock && ( $now - (int) $lock ) < 1800 ) {
			self::log( 'sync_skipped', array( 'reason' => 'locked' ) );
			return array( 'updated' => 0 );
		}
		
		set_transient( $lock_key, $now, 30 * MINUTE_IN_SECONDS );
		
		try {
			require_once PDI_PLUGIN_DIR . 'includes/class-pdi-api.php';
			$feed = PDI_API::fetch_feed( true );
			
			if ( is_wp_error( $feed ) ) {
				self::log( 'sync_error', array( 'error' => $feed->get_error_message() ) );
				return $feed;
			}
			
			$list = PDI_API::extract_products( $feed );
			
			if ( empty( $list ) ) {
				self::log( 'sync', array( 'updated' => 0, 'note' => 'Feed empty' ) );
				return array( 'updated' => 0 );
			}
			
			require_once PDI_PLUGIN_DIR . 'includes/class-pdi-helpers.php';
			
			$by_sku = array();
			foreach ( $list as $item ) {
				$sku = isset( $item['sku'] ) ? PDI_Helpers::sanitize_sku( (string) $item['sku'] ) : '';
				if ( ! empty( $sku ) ) {
					$by_sku[ strtoupper( $sku ) ] = $item;
				}
			}
			
			$batch_size = self::get_optimal_batch_size();
			$paged      = 1;
			$updated    = 0;
			$report     = array();
			
			do {
				$query = new WP_Query(
					array(
						'post_type'              => 'product',
						'post_status'            => 'any',
						'fields'                 => 'ids',
						'posts_per_page'         => $batch_size,
						'paged'                  => $paged,
						'no_found_rows'          => true,
						'orderby'                => 'ID',
						'order'                  => 'ASC',
						'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
							array(
								'key'     => '_sku',
								'compare' => 'EXISTS',
							),
						),
						'update_post_meta_cache' => false,
						'update_post_term_cache' => false,
					)
				);
				
				$ids = $query->posts;
				
				if ( empty( $ids ) ) {
					break;
				}

				// SECURE: Sanitize all IDs.
				$ids = array_map( 'absint', array_filter( $ids, 'is_numeric' ) );
				
				if ( empty( $ids ) ) {
					break;
				}

				$meta_data = self::batch_load_meta( $ids, array( '_sku', '_regular_price', '_stock' ) );

				foreach ( $ids as $pid ) {
					$sku = isset( $meta_data[ $pid ]['_sku'] ) ? (string) $meta_data[ $pid ]['_sku'] : '';
					if ( empty( $sku ) ) {
						continue;
					}

					$key = strtoupper( trim( $sku ) );
					if ( ! isset( $by_sku[ $key ] ) ) {
						continue;
					}

					$item = $by_sku[ $key ];
					
					$before = array(
						'price' => isset( $meta_data[ $pid ]['_regular_price'] ) ? (float) $meta_data[ $pid ]['_regular_price'] : 0.0,
						'stock' => isset( $meta_data[ $pid ]['_stock'] ) ? (int) $meta_data[ $pid ]['_stock'] : 0,
					);

					$result = self::create_or_update_wc_product( $item, $pid );
					
					if ( is_wp_error( $result ) ) {
						continue;
					}

					$after = array(
						'price' => (float) get_post_meta( $pid, '_regular_price', true ),
						'stock' => (int) get_post_meta( $pid, '_stock', true ),
					);

					$changed = array();
					if ( abs( $after['price'] - $before['price'] ) > 0.001 ) {
						$changed['price'] = array( 'from' => $before['price'], 'to' => $after['price'] );
					}
					if ( $after['stock'] !== $before['stock'] ) {
						$changed['stock'] = array( 'from' => $before['stock'], 'to' => $after['stock'] );
					}
					
					if ( ! empty( $changed ) ) {
						$updated++;
						$report[] = array( 'product_id' => $pid, 'sku' => $sku, 'changed' => $changed );
					}
				}

				self::log( 'sync_progress', array( 'batch' => $paged, 'updated' => $updated ) );
				$paged++;
				wp_reset_postdata();
				
				$more = ( count( $ids ) === $batch_size );
			} while ( $more );
			
			self::log(
				'sync',
				array(
					'updated' => $updated,
					'details' => $report,
					'note'    => 'Matched by SKU (batched with progress)',
				)
			);
			
			return array( 'updated' => $updated );
		} finally {
			delete_transient( $lock_key );
		}
	}

	/**
	 * Batch load meta data using WordPress functions.
	 *
	 * @param array $post_ids Post IDs.
	 * @param array $meta_keys Meta keys.
	 * @return array
	 */
	private static function batch_load_meta( $post_ids, $meta_keys ) {
		if ( empty( $post_ids ) || empty( $meta_keys ) ) {
			return array();
		}
		
		// SECURE: Sanitize all IDs.
		$post_ids = array_map( 'absint', $post_ids );
		$post_ids = array_filter( $post_ids );
		
		if ( empty( $post_ids ) ) {
			return array();
		}
		
		// SECURE: Limit to reasonable batch size.
		$post_ids = array_slice( $post_ids, 0, 1000 );
		
		$meta_data = array();
		
		// Use WordPress update_meta_cache to leverage built-in caching.
		update_meta_cache( 'post', $post_ids );
		
		foreach ( $post_ids as $post_id ) {
			foreach ( $meta_keys as $meta_key ) {
				// SECURE: Sanitize meta key.
				$meta_key = sanitize_key( $meta_key );
				
				// Use get_post_meta which uses WordPress caching.
				$value = get_post_meta( $post_id, $meta_key, true );
				
				if ( false !== $value && '' !== $value ) {
					if ( ! isset( $meta_data[ $post_id ] ) ) {
						$meta_data[ $post_id ] = array();
					}
					
					$meta_data[ $post_id ][ $meta_key ] = $value;
				}
			}
		}
		
		return $meta_data;
	}

	/**
	 * Get optimal batch size.
	 *
	 * @return int
	 */
	private static function get_optimal_batch_size() {
		$available_memory = self::get_available_memory();
		
		// SECURE: Calculate with bounds.
		$estimated_size = max( 50, min( self::SYNC_BATCH_SIZE, (int) ( $available_memory / 100000 ) ) );
		
		return $estimated_size;
	}

	/**
	 * Get available memory.
	 *
	 * @return int
	 */
	private static function get_available_memory() {
		$limit = ini_get( 'memory_limit' );
		
		if ( '-1' === $limit ) {
			return PHP_INT_MAX;
		}
		
		$limit = wp_convert_hr_to_bytes( $limit );
		$used  = memory_get_usage( true );
		
		return max( 0, $limit - $used );
	}

	/**
	 * Create or update WooCommerce product.
	 *
	 * @param array $item Product item.
	 * @param int   $existing_id Existing product ID.
	 * @return int|WP_Error
	 */
	private static function create_or_update_wc_product( $item, $existing_id = 0 ) {
		require_once PDI_PLUGIN_DIR . 'includes/class-pdi-helpers.php';
		
		$sku = isset( $item['sku'] ) ? PDI_Helpers::sanitize_sku( (string) $item['sku'] ) : '';
		
		if ( empty( $sku ) ) {
			return new WP_Error( 'no_sku', __( 'Item has no SKU.', 'puckator-dropship-importer' ) );
		}

		// SECURE: Sanitize title.
		$title = sanitize_text_field( $item['name'] ?? ( $item['title'] ?? 'Untitled' ) );
		if ( strlen( $title ) > 200 ) {
			$title = substr( $title, 0, 200 );
		}

		// SECURE: Allowed HTML tags for description.
		$allowed_desc_html = array(
			'p'      => array(),
			'br'     => array(),
			'strong' => array(),
			'em'     => array(),
			'ul'     => array(),
			'ol'     => array(),
			'li'     => array(),
		);
		
		// SECURE: Sanitize description.
		$desc = wp_kses(
			$item['description'] ?? ( $item['short_description'] ?? '' ),
			$allowed_desc_html
		);

		// SECURE: Extract and validate numeric values.
		$cost          = (float) PDI_Helpers::extract_price( $item );
		$stock         = (int) PDI_Helpers::extract_stock( $item );
		$weight        = (float) PDI_Helpers::extract_weight( $item );
		$shipping_cost = PDI_Helpers::get_shipping_for_weight( $weight );

		// Calculate final price.
		$settings = PDI_Helpers::get_settings();
		$base     = $cost + $shipping_cost;
		$vat      = $base * ( (float) $settings['vat'] / 100 );
		$paypal   = (float) $settings['paypal_fixed'] + $base * ( (float) $settings['paypal_percent'] / 100 );
		$subtotal = $base + $vat + $paypal;
		$final    = max( 0, round( $subtotal * ( 1 + ( (float) $settings['profit_percent'] / 100 ) ), 2 ) );
		$final_s  = number_format( (float) $final, 2, '.', '' );

		// Get or create product.
		$existing_id = absint( $existing_id );
		$product_id  = $existing_id > 0 ? $existing_id : wc_get_product_id_by_sku( $sku );
		$product     = $product_id ? wc_get_product( $product_id ) : new WC_Product_Simple();
		
		if ( ! $product ) {
			return new WP_Error( 'not_found', __( 'Product not found.', 'puckator-dropship-importer' ) );
		}

		// Update product.
		$product->set_name( $title );
		$product->set_description( $desc );
		$product->set_sku( $sku );
		$product->set_regular_price( $final_s );
		$product->set_manage_stock( true );
		$product->set_stock_quantity( $stock );

		if ( ! $product_id ) {
			$product->set_status( 'draft' );
		}

		$product_id = $product->save();
		
		// Update meta.
		update_post_meta( $product_id, PDI_Plugin::META_SOURCE_FLAG, 1 );
		update_post_meta( $product_id, PDI_Plugin::META_SOURCE_SKU, $sku );

		PDI_Helpers::invalidate_sku_cache();

		return $product_id;
	}

	/**
	 * Log event.
	 *
	 * @param string $action Action name.
	 * @param array  $data Event data.
	 * @return void
	 */
	private static function log( $action, $data = array() ) {
		require_once PDI_PLUGIN_DIR . 'includes/class-pdi-helpers.php';
		PDI_Helpers::log( $action, $data );
	}
}