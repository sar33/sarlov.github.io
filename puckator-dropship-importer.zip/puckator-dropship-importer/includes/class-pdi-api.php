<?php
/**
 * API Class
 *
 * @package Puckator_Dropship_Importer
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * API functionality class.
 *
 * @since 3.5.0
 */
class PDI_API {
	/**
	 * Maximum feed size.
	 *
	 * @var int
	 */
	const MAX_FEED_SIZE = 10485760;

	/**
	 * Get authentication token.
	 *
	 * @return string|false
	 */
	public static function get_token() {
		$cached = get_transient( PDI_Plugin::TOKEN_TRANSIENT );
		if ( $cached ) {
			return $cached;
		}

		$settings = self::get_settings();
		$api_base = (string) ( $settings['api_base'] ?? '' );
		$host     = wp_parse_url( $api_base, PHP_URL_HOST );

		$allowed_hosts = apply_filters(
			'pdi_allowed_api_hosts',
			array(
				'www.puckator-dropship.co.uk',
				'puckator-dropship.co.uk',
			)
		);
		
		if ( ! is_array( $allowed_hosts ) || ! in_array( $host, $allowed_hosts, true ) ) {
			return false;
		}

		$url = untrailingslashit( $api_base ) . '/rest/all/V1/integration/customer/token';

		if ( stripos( $url, 'https://' ) !== 0 ) {
			return false;
		}

		$username = (string) ( $settings['username'] ?? '' );
		$password = (string) ( $settings['password'] ?? '' );

		if ( empty( $username ) || empty( $password ) ) {
			return false;
		}

		$response = wp_safe_remote_post(
			$url,
			array(
				'headers'             => array(
					'Content-Type' => 'application/json',
					'Accept'       => 'application/json',
				),
				'body'                => wp_json_encode( array( 'username' => $username, 'password' => $password ) ),
				'timeout'             => 30,
				'redirection'         => 3,
				'reject_unsafe_urls'  => true,
				'limit_response_size' => 256 * 1024,
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}

		$body  = wp_remote_retrieve_body( $response );
		$data  = json_decode( $body, true );
		$token = is_string( $data ) ? $data : ( $data['token'] ?? trim( $body, "\" \r\n" ) );

		if ( empty( $token ) || ! is_string( $token ) || strlen( $token ) < 10 ) {
			return false;
		}

		set_transient( PDI_Plugin::TOKEN_TRANSIENT, $token, 45 * MINUTE_IN_SECONDS );
		
		return $token;
	}

	/**
	 * Fetch product feed.
	 *
	 * @param bool $bypass_cache Whether to bypass cache.
	 * @return array|WP_Error
	 */
	public static function fetch_feed( $bypass_cache = false ) {
		$token = self::get_token();
		
		if ( ! $token ) {
			return new WP_Error( 'token', __( 'Failed to get authentication token.', 'puckator-dropship-importer' ) );
		}

		$settings = self::get_settings();
		$endpoint = ltrim( (string) ( $settings['endpoint'] ?? '' ), '/' );

		if ( empty( $endpoint ) || 
			 strlen( $endpoint ) > 512 ||
			 strpos( $endpoint, '..' ) !== false ||
			 strpos( $endpoint, '//' ) !== false ||
			 preg_match( '#%2f#i', $endpoint ) ||
			 ! preg_match( '#^[a-z0-9/_\.\-\?\=\,&]*$#i', $endpoint ) ) {
			return new WP_Error( 'bad_endpoint', __( 'Invalid endpoint format.', 'puckator-dropship-importer' ) );
		}

		$api_base = (string) ( $settings['api_base'] ?? '' );
		$host     = wp_parse_url( $api_base, PHP_URL_HOST );

		$allowed_hosts = apply_filters(
			'pdi_allowed_api_hosts',
			array(
				'www.puckator-dropship.co.uk',
				'puckator-dropship.co.uk',
			)
		);

		if ( ! is_array( $allowed_hosts ) || ! in_array( $host, $allowed_hosts, true ) ) {
			return new WP_Error( 'bad_host', __( 'API host is not in the allowed list.', 'puckator-dropship-importer' ) );
		}

		$url = untrailingslashit( $api_base ) . '/' . $endpoint;

		if ( stripos( $url, 'https://' ) !== 0 ) {
			return new WP_Error( 'insecure_url', __( 'HTTPS is required for API requests.', 'puckator-dropship-importer' ) );
		}

		if ( ! $bypass_cache ) {
			$cached = get_transient( 'pdi_feed_cache' );
			if ( is_array( $cached ) && ! empty( $cached ) ) {
				return $cached;
			}
		}

		$response = wp_safe_remote_get(
			$url,
			array(
				'headers'             => array(
					'Authorization' => 'Bearer ' . $token,
					'Accept'        => 'application/json',
				),
				'timeout'             => 30,
				'redirection'         => 3,
				'reject_unsafe_urls'  => true,
				'limit_response_size' => self::MAX_FEED_SIZE,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );

				if ( 200 !== $code ) {
			return new WP_Error(
				'http',
				sprintf(
					/* translators: %d: HTTP response code */
					__( 'Feed HTTP error: %d', 'puckator-dropship-importer' ),
					$code
				)
			);
		}
		if ( strlen( $body ) > self::MAX_FEED_SIZE ) {
			return new WP_Error( 'oversize', __( 'Feed response too large.', 'puckator-dropship-importer' ) );
		}

		$data = json_decode( $body, true, 32 );
		
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $data ) ) {
			return new WP_Error(
	'json',
	sprintf(
		/* translators: %s: JSON error message */
		__( 'Invalid JSON from feed: %s', 'puckator-dropship-importer' ),
		json_last_error_msg()
	)
);
}

		set_transient( 'pdi_feed_cache', $data, 10 * MINUTE_IN_SECONDS );
		
		return $data;
	}

	/**
	 * Extract products from feed.
	 *
	 * @param array $feed Feed data.
	 * @return array
	 */
	public static function extract_products( $feed ) {
		if ( isset( $feed['data'] ) && is_array( $feed['data'] ) ) {
			return $feed['data'];
		}
		if ( isset( $feed['items'] ) && is_array( $feed['items'] ) ) {
			return $feed['items'];
		}
		if ( isset( $feed[0] ) ) {
			return $feed;
		}
		return array();
	}

	/**
	 * Get settings.
	 *
	 * @return array
	 */
	private static function get_settings() {
		$defaults = array(
			'api_base'         => 'https://www.puckator-dropship.co.uk',
			'endpoint'         => PDI_Plugin::DEFAULT_ENDPOINT,
			'username'         => '',
			'password'         => '',
			'vat'              => '20.00',
			'paypal_percent'   => '2.90',
			'paypal_fixed'     => '0.30',
			'profit_percent'   => '20.00',
			'stock_field_path' => '',
			'price_field_key'  => '',
			'shipping_table'   => '[{"min":0,"max":0.1,"cost":2.49},{"min":0.1,"max":1,"cost":3.99},{"min":1,"max":1.5,"cost":4.99},{"min":1.5,"max":2,"cost":5.99}]',
		);
		
		$settings = get_option( PDI_Plugin::OPT_SETTINGS, array() );
		
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}
		
		$settings = wp_parse_args( $settings, $defaults );
		
		// Decrypt password.
		if ( ! empty( $settings['password'] ) ) {
			require_once PDI_PLUGIN_DIR . 'includes/class-pdi-helpers.php';
			$decrypted = PDI_Helpers::decrypt_field( $settings['password'] );
			if ( ! empty( $decrypted ) ) {
				$settings['password'] = $decrypted;
			}
		}
		
		return $settings;
	}
}