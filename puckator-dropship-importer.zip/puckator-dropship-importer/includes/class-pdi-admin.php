<?php
/**
 * Admin Class
 *
 * @package Puckator_Dropship_Importer
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin functionality class.
 *
 * @since 3.5.0
 */
class PDI_Admin {
	/**
	 * Instance.
	 *
	 * @var PDI_Admin|null
	 */
	private static $instance = null;

	/**
	 * Get instance.
	 *
	 * @return PDI_Admin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin' ) );
		add_action( 'admin_init', array( $this, 'add_security_headers' ) );
	}

	/**
	 * Add security headers.
	 *
	 * @return void
	 */
	public function add_security_headers() {
		if ( ! is_admin() || ! isset( $_GET['page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		// SECURE: Sanitize page parameter.
		$page = sanitize_text_field( wp_unslash( $_GET['page'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		
		if ( strpos( $page, 'pdi-' ) !== 0 ) {
			return;
		}

		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: DENY' );
		header( 'X-XSS-Protection: 1; mode=block' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	}

	/**
	 * Register admin menu.
	 *
	 * @return void
	 */
	public function admin_menu() {
		add_menu_page(
			__( 'Puckator', 'puckator-dropship-importer' ),
			__( 'Puckator', 'puckator-dropship-importer' ),
			'manage_options',
			'pdi-dashboard',
			array( $this, 'page_dashboard' ),
			'dashicons-cart',
			56
		);
		
		add_submenu_page(
			'pdi-dashboard',
			__( 'Settings', 'puckator-dropship-importer' ),
			__( 'Settings', 'puckator-dropship-importer' ),
			'manage_options',
			'pdi-settings',
			array( $this, 'page_settings' )
		);
		
		add_submenu_page(
			'pdi-dashboard',
			__( 'Search & Import', 'puckator-dropship-importer' ),
			__( 'Search & Import', 'puckator-dropship-importer' ),
			'edit_products',
			'pdi-search',
			array( $this, 'page_search' )
		);
		
		add_submenu_page(
			'pdi-dashboard',
			__( 'Logs', 'puckator-dropship-importer' ),
			__( 'Logs', 'puckator-dropship-importer' ),
			'manage_woocommerce',
			'pdi-logs',
			array( $this, 'page_logs' )
		);
	}

	/**
	 * Enqueue admin scripts and styles.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_admin( $hook ) {
		$allowed = array(
			'toplevel_page_pdi-dashboard',
			'puckator_page_pdi-settings',
			'puckator_page_pdi-search',
			'puckator_page_pdi-logs',
		);
		
		if ( ! in_array( $hook, $allowed, true ) ) {
			return;
		}

		wp_enqueue_script(
			'pdi-admin',
			PDI_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			PDI_VERSION,
			true
		);
		
		wp_localize_script(
			'pdi-admin',
			'PDI',
			array(
				'ajax'  => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'pdi_nonce' ),
			)
		);

		wp_enqueue_style(
			'pdi-admin-css',
			PDI_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			PDI_VERSION
		);
	}

	/**
	 * Dashboard page.
	 *
	 * @return void
	 */
	public function page_dashboard() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'puckator-dropship-importer' ) );
		}
		
		require_once PDI_PLUGIN_DIR . 'includes/views/dashboard.php';
	}

	/**
	 * Settings page.
	 *
	 * @return void
	 */
	public function page_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'puckator-dropship-importer' ) );
		}
		
		require_once PDI_PLUGIN_DIR . 'includes/views/settings.php';
	}

	/**
	 * Search page.
	 *
	 * @return void
	 */
	public function page_search() {
		if ( ! current_user_can( 'edit_products' ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'puckator-dropship-importer' ) );
		}
		
		require_once PDI_PLUGIN_DIR . 'includes/views/search.php';
	}

	/**
	 * Logs page.
	 *
	 * @return void
	 */
	public function page_logs() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'puckator-dropship-importer' ) );
		}
		
		require_once PDI_PLUGIN_DIR . 'includes/views/logs.php';
	}
}