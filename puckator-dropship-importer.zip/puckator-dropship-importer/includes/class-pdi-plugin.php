<?php
/**
 * Main Plugin Class
 *
 * @package Puckator_Dropship_Importer
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin class.
 *
 * @since 3.5.0
 */
final class PDI_Plugin {
	/**
	 * Settings option name.
	 *
	 * @var string
	 */
	const OPT_SETTINGS = 'pdi_settings_v30';

	/**
	 * Logs option name.
	 *
	 * @var string
	 */
	const OPT_LOGS = 'pdi_logs_v30';

	/**
	 * Security logs option name.
	 *
	 * @var string
	 */
	const OPT_SECURITY_LOGS = 'pdi_security_logs_v32';

	/**
	 * Token transient name.
	 *
	 * @var string
	 */
	const TOKEN_TRANSIENT = 'pdi_token_v30';

	/**
	 * Cache version transient name.
	 *
	 * @var string
	 */
	const CACHE_VERSION_TRANSIENT = 'pdi_cache_version_v32';

	/**
	 * Cron hook name.
	 *
	 * @var string
	 */
	const CRON_HOOK = 'pdi_daily_sync_v30';

	/**
	 * Maximum log entries.
	 *
	 * @var int
	 */
	const LOG_CAP = 800;

	/**
	 * Maximum security log entries.
	 *
	 * @var int
	 */
	const SECURITY_LOG_CAP = 500;

	/**
	 * Meta key for source flag.
	 *
	 * @var string
	 */
	const META_SOURCE_FLAG = '_pdi_source_v30';

	/**
	 * Meta key for source SKU.
	 *
	 * @var string
	 */
	const META_SOURCE_SKU = '_pdi_sku_v30';

	/**
	 * Default API endpoint.
	 *
	 * @var string
	 */
	const DEFAULT_ENDPOINT = '/rest/puck_dsuk/V1/customer/feed/products';

	/**
	 * Plugin instance.
	 *
	 * @var PDI_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Get plugin instance.
	 *
	 * @return PDI_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->includes();
		$this->init_hooks();
	}

	/**
	 * Include required files.
	 *
	 * @return void
	 */
	private function includes() {
		require_once PDI_PLUGIN_DIR . 'includes/class-pdi-admin.php';
		require_once PDI_PLUGIN_DIR . 'includes/class-pdi-api.php';
		require_once PDI_PLUGIN_DIR . 'includes/class-pdi-sync.php';
		require_once PDI_PLUGIN_DIR . 'includes/class-pdi-ajax.php';
	}

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	private function init_hooks() {
		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
		
		register_activation_hook( PDI_PLUGIN_FILE, array( $this, 'activate' ) );
		register_deactivation_hook( PDI_PLUGIN_FILE, array( $this, 'deactivate' ) );
		
		// Initialize components.
		PDI_Admin::instance();
		PDI_AJAX::instance();
		
		add_action( self::CRON_HOOK, array( 'PDI_Sync', 'cron_sync' ) );
	}

	/**
	 * Load plugin textdomain.
	 *
	 * @return void
	 */
	public function load_textdomain() {
		// SECURE: Use recommended method for loading translations
		if ( function_exists( 'determine_locale' ) ) {
			$locale = determine_locale();
		} else {
			$locale = is_admin() ? get_user_locale() : get_locale();
		}
		
		// SECURE: Sanitize locale
		$locale = sanitize_text_field( $locale );
		
		$mofile = PDI_PLUGIN_DIR . 'languages/puckator-dropship-importer-' . $locale . '.mo';
		
		// Load translation file directly instead of using load_plugin_textdomain
		load_textdomain( 'puckator-dropship-importer', $mofile );
	}

	/**
	 * Activation hook.
	 *
	 * @return void
	 */
	public function activate() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			deactivate_plugins( PDI_PLUGIN_BASENAME );
			wp_die(
				'<h1>' . esc_html__( 'WooCommerce Required', 'puckator-dropship-importer' ) . '</h1>' .
				'<p>' . esc_html__( 'Puckator Dropship Importer requires WooCommerce to be installed and active.', 'puckator-dropship-importer' ) . '</p>' .
				'<p><a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">' . esc_html__( 'Return to Plugins', 'puckator-dropship-importer' ) . '</a></p>',
				esc_html__( 'Plugin Activation Error', 'puckator-dropship-importer' ),
				array( 'back_link' => true )
			);
		}
		
		$this->ensure_cron_scheduled();
		
		if ( false === get_option( self::OPT_SETTINGS ) ) {
			add_option( self::OPT_SETTINGS, array(), '', 'no' );
		}
		if ( false === get_option( self::OPT_LOGS ) ) {
			add_option( self::OPT_LOGS, array(), '', 'no' );
		}
		if ( false === get_option( self::OPT_SECURITY_LOGS ) ) {
			add_option( self::OPT_SECURITY_LOGS, array(), '', 'no' );
		}
	}

	/**
	 * Deactivation hook.
	 *
	 * @return void
	 */
	public function deactivate() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	/**
	 * Ensure cron is scheduled.
	 *
	 * @return void
	 */
	private function ensure_cron_scheduled() {
		$next = wp_next_scheduled( self::CRON_HOOK );
		
		if ( $next ) {
			$tz             = wp_timezone();
			$scheduled_time = new DateTime( '@' . $next );
			$scheduled_time->setTimezone( $tz );
			
			$target_time = new DateTime( 'today 06:00:00', $tz );
			if ( $target_time <= new DateTime( 'now', $tz ) ) {
				$target_time->modify( '+1 day' );
			}
			
			if ( abs( $next - $target_time->getTimestamp() ) < 3600 ) {
				return;
			}
		}
		
		wp_clear_scheduled_hook( self::CRON_HOOK );
		
		$tz  = wp_timezone();
		$now = new DateTime( 'now', $tz );
		$run = new DateTime( 'today 06:00:00', $tz );
		
		if ( $run <= $now ) {
			$run->modify( '+1 day' );
		}
		
		wp_schedule_event( $run->getTimestamp(), 'daily', self::CRON_HOOK );
	}
}