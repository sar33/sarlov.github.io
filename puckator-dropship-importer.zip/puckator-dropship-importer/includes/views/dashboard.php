<?php
/**
 * Dashboard View
 *
 * @package Puckator_Dropship_Importer
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tz   = wp_timezone_string();
$next = wp_next_scheduled( PDI_Plugin::CRON_HOOK );

// Show sync lock status.
$lock_key    = 'pdi_sync_lock_' . wp_hash( home_url(), 'nonce' );
$lock        = get_transient( $lock_key );
$lock_status = '';

if ( $lock ) {
	$lock_time = absint( $lock );
	$elapsed   = time() - $lock_time;
	
	if ( $elapsed < 1800 ) {
		$lock_status = '<p style="color:#d63638;"><strong>⚠️ ' . 
			sprintf(
				/* translators: %s: human-readable time difference */
				esc_html__( 'Sync is currently running (started %s ago)', 'puckator-dropship-importer' ),
				human_time_diff( $lock_time )
			) . 
			'</strong></p>';
	}
}

// SECURE: Handle clear lock request.
if ( isset( $_POST['pdi_clear_lock'] ) && 
	 isset( $_POST['pdi_clear_lock_nonce'] ) &&
	 wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['pdi_clear_lock_nonce'] ) ), 'pdi_clear_lock' ) ) {
	delete_transient( $lock_key );
	echo '<div class="updated"><p>' . esc_html__( '✅ Sync lock cleared successfully!', 'puckator-dropship-importer' ) . '</p></div>';
	echo '<script>window.location.href = window.location.href.split("?")[0];</script>';
}

?>
<div class="wrap">
	<h1><?php esc_html_e( 'Puckator Dropship Importer', 'puckator-dropship-importer' ); ?></h1>
	
	<p>
		<?php
		echo wp_kses_post(
			sprintf(
				/* translators: 1: time, 2: timezone */
				__( 'Daily sync runs at %1$s using site timezone (%2$s).', 'puckator-dropship-importer' ),
				'<strong>06:00</strong>',
				'<strong>' . esc_html( $tz ) . '</strong>'
			)
		);
		?>
	</p>
	
	<p>
		<?php
		$next_run_text = $next ? esc_html( wp_date( 'Y-m-d H:i', $next, wp_timezone() ) ) : esc_html__( 'not scheduled', 'puckator-dropship-importer' );
		
		echo wp_kses_post(
			sprintf(
				/* translators: %s: next scheduled time */
				__( 'Next run: %s', 'puckator-dropship-importer' ),
				'<strong>' . $next_run_text . '</strong>'
			)
		);
		?>
	</p>
	
	<?php
	// SECURE: Output lock status (already escaped above).
	echo wp_kses_post( $lock_status );
	?>
	
	<p>
		<button id="pdi-sync-now" class="button button-primary">
			<?php esc_html_e( 'Sync now', 'puckator-dropship-importer' ); ?>
		</button>
		<span id="pdi-sync-status"></span>
	</p>
	
	<?php if ( $lock && current_user_can( 'manage_options' ) ) : ?>
		<p>
			<form method="post" style="display:inline;">
				<?php wp_nonce_field( 'pdi_clear_lock', 'pdi_clear_lock_nonce' ); ?>
				<button type="submit" name="pdi_clear_lock" class="button">
					<?php esc_html_e( '🔓 Clear Sync Lock', 'puckator-dropship-importer' ); ?>
				</button>
			</form>
		</p>
	<?php endif; ?>
</div>