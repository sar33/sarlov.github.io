<?php
/**
 * Search View
 *
 * @package Puckator_Dropship_Importer
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap">
	<h1><?php esc_html_e( 'Search & Import', 'puckator-dropship-importer' ); ?></h1>
	<p>
		<input id="pdi-keyword" type="text" class="regular-text" placeholder="<?php esc_attr_e( 'Enter keyword or SKU', 'puckator-dropship-importer' ); ?>" maxlength="200">
		<label style="margin-left:10px;">
			<input type="checkbox" id="pdi-search-sku" value="1">
			<?php esc_html_e( 'Search by SKU only', 'puckator-dropship-importer' ); ?>
		</label>
		<button id="pdi-search-btn" class="button"><?php esc_html_e( 'Search', 'puckator-dropship-importer' ); ?></button>
	</p>
	<div id="pdi-results"></div>
	<div id="pdi-import-status" style="margin-top:10px;"></div>
</div>