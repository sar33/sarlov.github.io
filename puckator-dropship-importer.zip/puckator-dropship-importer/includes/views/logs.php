<?php
/**
 * Logs View
 *
 * @package Puckator_Dropship_Importer
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once PDI_PLUGIN_DIR . 'includes/class-pdi-helpers.php';

// SECURE: Handle clear logs request.
if ( isset( $_POST['pdi_clear_old_nonce'] ) && 
	 wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['pdi_clear_old_nonce'] ) ), 'pdi_clear_old' ) ) {
	$logs = get_option( PDI_Plugin::OPT_LOGS, array() );
	if ( is_array( $logs ) && count( $logs ) > 100 ) {
		$logs = array_slice( $logs, -100 );
		update_option( PDI_Plugin::OPT_LOGS, $logs, false );
		PDI_Helpers::log_security_event( 'logs_cleared', array( 'user_id' => get_current_user_id() ) );
		echo '<div class="updated"><p>' . esc_html__( '🧹 Old logs cleared. Kept latest 100 entries.', 'puckator-dropship-importer' ) . '</p></div>';
	} else {
		echo '<div class="notice notice-info"><p>' . esc_html__( 'No old logs to clear.', 'puckator-dropship-importer' ) . '</p></div>';
	}
}

$logs = get_option( PDI_Plugin::OPT_LOGS, array() );
$logs = is_array( $logs ) ? array_reverse( $logs ) : array();

ob_start();
wp_nonce_field( 'pdi_clear_old', 'pdi_clear_old_nonce' );
$nonce_field = ob_get_clean();
?>
<div class="wrap">
	<h1 style="display:flex;justify-content:space-between;align-items:center;">
		<?php esc_html_e( 'Logs', 'puckator-dropship-importer' ); ?>
		<form method="post" onsubmit="return confirm('<?php echo esc_js( __( 'Are you sure you want to remove old logs (keeping last 100)?', 'puckator-dropship-importer' ) ); ?>');" style="margin:0;">
			<?php echo wp_kses( $nonce_field, array( 'input' => array( 'type' => array(), 'id' => array(), 'name' => array(), 'value' => array() ) ) ); ?>
			<button type="submit" class="button">
				<?php esc_html_e( '🧹 Clear Old Logs', 'puckator-dropship-importer' ); ?>
			</button>
		</form>
	</h1>
	
	<?php if ( empty( $logs ) ) : ?>
		<p><?php esc_html_e( 'No logs yet.', 'puckator-dropship-importer' ); ?></p>
	<?php else : ?>
		<table class="widefat striped pdi-log-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Date', 'puckator-dropship-importer' ); ?></th>
					<th><?php esc_html_e( 'Action', 'puckator-dropship-importer' ); ?></th>
					<th><?php esc_html_e( 'Summary', 'puckator-dropship-importer' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php
				$allowed_html = PDI_Helpers::get_allowed_log_html();
				
				foreach ( $logs as $row ) {
					// SECURE: Sanitize timestamp.
					$timestamp = isset( $row['ts'] ) ? absint( $row['ts'] ) : 0;
					$date      = $timestamp > 0 ? wp_date( 'Y-m-d H:i:s', $timestamp, wp_timezone() ) : '';
					$action    = isset( $row['action'] ) ? sanitize_text_field( $row['action'] ) : '';
					$data      = isset( $row['data'] ) && is_array( $row['data'] ) ? $row['data'] : array();

					$class = 'pdi-row-info';
					if ( false !== stripos( $action, 'error' ) || isset( $data['error'] ) ) {
						$class = 'pdi-row-error';
					} elseif ( in_array( $action, array( 'sync', 'import', 'settings_saved' ), true ) ) {
						$class = 'pdi-row-success';
					} elseif ( in_array( $action, array( 'sync_progress', 'sync_skipped' ), true ) ) {
						$class = 'pdi-row-info';
					}

					$summary = PDI_Helpers::format_log_summary( $data );
					?>
					<tr class="<?php echo esc_attr( $class ); ?>">
						<td><?php echo esc_html( $date ); ?></td>
						<td><?php echo esc_html( $action ); ?></td>
						<td><?php echo wp_kses( $summary, $allowed_html ); ?></td>
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
	<?php endif; ?>
</div>