<?php
/**
 * Settings View
 *
 * @package Puckator_Dropship_Importer
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once PDI_PLUGIN_DIR . 'includes/class-pdi-helpers.php';

$settings = PDI_Helpers::get_settings();
$nonce_ok = false;

if ( isset( $_POST['pdi_settings_nonce'] ) ) {
	$nonce_raw = sanitize_text_field( wp_unslash( $_POST['pdi_settings_nonce'] ) );
	$nonce_ok  = wp_verify_nonce( $nonce_raw, 'pdi_save_settings' );
}

if ( $nonce_ok ) {
	PDI_Helpers::log_security_event(
		'settings_change_attempted',
		array( 'user_id' => get_current_user_id() )
	);

	$save = array();

	// SECURE: Validate API Base URL.
	$api_base_input = isset( $_POST['api_base'] ) ? 
		esc_url_raw( wp_unslash( $_POST['api_base'] ) ) : 
		$settings['api_base'];
		
	if ( stripos( $api_base_input, 'https://' ) !== 0 ) {
		add_settings_error(
			'pdi_settings',
			'pdi_insecure_api_base',
			esc_html__( 'API Base URL must start with https://', 'puckator-dropship-importer' ),
			'error'
		);
		$save['api_base'] = $settings['api_base'];
	} else {
		$save['api_base'] = $api_base_input;
	}

	// SECURE: Validate endpoint.
	$endpoint_in = isset( $_POST['endpoint'] ) ? 
		sanitize_text_field( wp_unslash( $_POST['endpoint'] ) ) : 
		$settings['endpoint'];
	$endpoint_in = ltrim( $endpoint_in, '/' );
	
	if ( strlen( $endpoint_in ) > 512 || 
		 ! preg_match( '#^[a-z0-9/_\.\-\?\=\,&]*$#i', $endpoint_in ) ||
		 strpos( $endpoint_in, '..' ) !== false ||
		 strpos( $endpoint_in, '//' ) !== false ) {
		add_settings_error(
			'pdi_settings',
			'pdi_bad_endpoint',
			esc_html__( 'Endpoint contains invalid characters or format.', 'puckator-dropship-importer' ),
			'error'
		);
		$save['endpoint'] = $settings['endpoint'];
	} else {
		$save['endpoint'] = $endpoint_in;
	}

	// SECURE: Validate username.
	$username_input = isset( $_POST['username'] ) ? 
		sanitize_email( wp_unslash( $_POST['username'] ) ) : 
		'';
		
	if ( ! empty( $username_input ) && ! is_email( $username_input ) ) {
		add_settings_error(
			'pdi_settings',
			'pdi_invalid_email',
			esc_html__( 'Username must be a valid email address.', 'puckator-dropship-importer' ),
			'error'
		);
		$save['username'] = $settings['username'];
	} else {
		$save['username'] = $username_input;
	}

	// SECURE: Handle password - sanitize as text first, then validate.
	$current_raw          = get_option( PDI_Plugin::OPT_SETTINGS, array() );
	$current_encrypted_pw = isset( $current_raw['password'] ) ? (string) $current_raw['password'] : '';
	
	// SECURE: Sanitize password input (preserves special chars but removes slashes and validates UTF-8).
	$plain_pw = isset( $_POST['password'] ) ? sanitize_textarea_field( wp_unslash( $_POST['password'] ) ) : '';
	
	if ( ! empty( $plain_pw ) ) {
		$pw_validation = PDI_Helpers::validate_password( $plain_pw );
		if ( is_wp_error( $pw_validation ) ) {
			add_settings_error(
				'pdi_settings',
				'pdi_invalid_password',
				$pw_validation->get_error_message(),
				'error'
			);
			$save['password'] = $current_encrypted_pw;
		} else {
			try {
				$save['password'] = PDI_Helpers::encrypt_field( $plain_pw );
			} catch ( Exception $e ) {
				add_settings_error(
					'pdi_settings',
					'pdi_encrypt_failed',
					esc_html__( 'Failed to encrypt password.', 'puckator-dropship-importer' ),
					'error'
				);
				$save['password'] = $current_encrypted_pw;
			}
		}
	} else {
		$save['password'] = $current_encrypted_pw;
	}

	// SECURE: Validate numeric fields.
	$num_fields = array( 'vat', 'paypal_percent', 'paypal_fixed', 'profit_percent' );
	foreach ( $num_fields as $field ) {
		$input_val = isset( $_POST[ $field ] ) ? 
			sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) : 
			$settings[ $field ];
		$val            = PDI_Helpers::validate_numeric_setting( $input_val, $field );
		$save[ $field ] = number_format( $val, 2, '.', '' );
	}

	// SECURE: Validate field paths - sanitize immediately.
	$stock_field_path_raw = isset( $_POST['stock_field_path'] ) ? 
		sanitize_text_field( wp_unslash( $_POST['stock_field_path'] ) ) : 
		$settings['stock_field_path'];
	$save['stock_field_path'] = PDI_Helpers::sanitize_field_path( $stock_field_path_raw );
	
	$price_field_key_raw = isset( $_POST['price_field_key'] ) ? 
		sanitize_text_field( wp_unslash( $_POST['price_field_key'] ) ) : 
		$settings['price_field_key'];
	$save['price_field_key'] = PDI_Helpers::sanitize_field_path( $price_field_key_raw );

	// SECURE: Validate shipping table - sanitize as textarea to preserve JSON structure.
	$shipping_json = isset( $_POST['shipping_table'] ) ? 
		sanitize_textarea_field( wp_unslash( $_POST['shipping_table'] ) ) : 
		( $settings['shipping_table'] ?? '' );
	
	if ( strlen( $shipping_json ) > 65536 ) {
		add_settings_error(
			'pdi_settings',
			'pdi_ship_oversize',
			esc_html__( 'Shipping table too large.', 'puckator-dropship-importer' ),
			'error'
		);
		$save['shipping_table'] = $settings['shipping_table'];
	} else {
		$validated_shipping = PDI_Helpers::validate_shipping_table( $shipping_json );
		if ( is_wp_error( $validated_shipping ) ) {
			add_settings_error(
				'pdi_settings',
				'pdi_ship_invalid',
				$validated_shipping->get_error_message(),
				'error'
			);
			$save['shipping_table'] = $settings['shipping_table'];
		} else {
			$save['shipping_table'] = $validated_shipping;
		}
	}

	update_option( PDI_Plugin::OPT_SETTINGS, $save, false );
	delete_transient( PDI_Plugin::TOKEN_TRANSIENT );
	delete_transient( 'pdi_feed_cache' );
	PDI_Helpers::invalidate_sku_cache();

	PDI_Helpers::log( 'settings_saved', array( 'message' => 'Settings updated successfully.' ) );
	PDI_Helpers::log_security_event( 'settings_changed', array( 'user_id' => get_current_user_id() ) );
	
	echo '<div class="updated"><p>' . esc_html__( 'Settings saved.', 'puckator-dropship-importer' ) . '</p></div>';

	$settings = PDI_Helpers::get_settings();
}

settings_errors( 'pdi_settings' );
?>
<div class="wrap">
	<h1><?php esc_html_e( 'Puckator Importer Settings', 'puckator-dropship-importer' ); ?></h1>
	<form method="post" action="">
		<?php wp_nonce_field( 'pdi_save_settings', 'pdi_settings_nonce' ); ?>
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row">
						<label for="api_base"><?php esc_html_e( 'API Base URL', 'puckator-dropship-importer' ); ?></label>
					</th>
					<td>
						<input name="api_base" type="url" id="api_base" value="<?php echo esc_attr( $settings['api_base'] ); ?>" class="regular-text" placeholder="https://www.puckator-dropship.co.uk" required>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="endpoint"><?php esc_html_e( 'API Endpoint', 'puckator-dropship-importer' ); ?></label>
					</th>
					<td>
						<input name="endpoint" type="text" id="endpoint" value="<?php echo esc_attr( $settings['endpoint'] ); ?>" class="regular-text" placeholder="/rest/puck_dsuk/V1/customer/feed/products">
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="username"><?php esc_html_e( 'API Username (Email)', 'puckator-dropship-importer' ); ?></label>
					</th>
					<td>
						<input name="username" type="email" id="username" value="<?php echo esc_attr( $settings['username'] ); ?>" class="regular-text" required>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="password"><?php esc_html_e( 'API Password', 'puckator-dropship-importer' ); ?></label>
					</th>
					<td>
						<input name="password" type="password" id="password" value="" placeholder="<?php esc_attr_e( '(leave blank to keep existing)', 'puckator-dropship-importer' ); ?>" class="regular-text" autocomplete="new-password">
						<p class="description"><?php esc_html_e( 'Password is encrypted using AES-256-CBC with HMAC authentication.', 'puckator-dropship-importer' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="vat"><?php esc_html_e( 'VAT %', 'puckator-dropship-importer' ); ?></label>
					</th>
					<td>
						<input name="vat" type="number" id="vat" value="<?php echo esc_attr( $settings['vat'] ); ?>" step="0.01" min="0" max="100">
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="paypal_percent"><?php esc_html_e( 'PayPal %', 'puckator-dropship-importer' ); ?></label>
					</th>
					<td>
						<input name="paypal_percent" type="number" id="paypal_percent" value="<?php echo esc_attr( $settings['paypal_percent'] ); ?>" step="0.01" min="0" max="100">
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="paypal_fixed"><?php esc_html_e( 'PayPal Fixed Fee', 'puckator-dropship-importer' ); ?></label>
					</th>
					<td>
						<input name="paypal_fixed" type="number" id="paypal_fixed" value="<?php echo esc_attr( $settings['paypal_fixed'] ); ?>" step="0.01" min="0">
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="profit_percent"><?php esc_html_e( 'Profit %', 'puckator-dropship-importer' ); ?></label>
					</th>
					<td>
						<input name="profit_percent" type="number" id="profit_percent" value="<?php echo esc_attr( $settings['profit_percent'] ); ?>" step="0.01" min="0" max="100">
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="stock_field_path"><?php esc_html_e( 'Stock Field Path (optional)', 'puckator-dropship-importer' ); ?></label>
					</th>
					<td>
						<input name="stock_field_path" type="text" id="stock_field_path" value="<?php echo esc_attr( $settings['stock_field_path'] ); ?>" class="regular-text" placeholder="<?php esc_attr_e( 'e.g. extension_attributes.stock_item.qty', 'puckator-dropship-importer' ); ?>">
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="price_field_key"><?php esc_html_e( 'Price Field Key (optional)', 'puckator-dropship-importer' ); ?></label>
					</th>
					<td>
						<input name="price_field_key" type="text" id="price_field_key" value="<?php echo esc_attr( $settings['price_field_key'] ); ?>" class="regular-text" placeholder="<?php esc_attr_e( 'e.g. price_ex_vat', 'puckator-dropship-importer' ); ?>">
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="shipping_table"><?php esc_html_e( 'Shipping Table (JSON)', 'puckator-dropship-importer' ); ?></label>
					</th>
					<td>
						<textarea name="shipping_table" id="shipping_table" rows="5" class="large-text code"><?php echo esc_textarea( $settings['shipping_table'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Example: [{"min":0,"max":1,"cost":3.99},{"min":1,"max":2,"cost":5.99}]', 'puckator-dropship-importer' ); ?></p>
					</td>
				</tr>
			</tbody>
		</table>
		<?php submit_button( __( 'Save Settings', 'puckator-dropship-importer' ) ); ?>
	</form>
</div>