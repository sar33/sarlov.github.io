<?php
/**
 * AJAX Class
 *
 * @package Puckator_Dropship_Importer
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AJAX functionality class.
 *
 * @since 3.5.0
 */
class PDI_AJAX {
	/**
	 * Instance.
	 *
	 * @var PDI_AJAX|null
	 */
	private static $instance = null;

	/**
	 * Get instance.
	 *
	 * @return PDI_AJAX
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'wp_ajax_pdi_search', array( $this, 'ajax_search' ) );
		add_action( 'wp_ajax_pdi_import', array( $this, 'ajax_import' ) );
		add_action( 'wp_ajax_pdi_manual_sync', array( $this, 'ajax_manual_sync' ) );
	}

	/**
	 * AJAX search handler.
	 *
	 * @return void
	 */
	public function ajax_search() {
		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( __( 'Unauthorized', 'puckator-dropship-importer' ), 403 );
		}
		
		if ( ! check_ajax_referer( 'pdi_nonce', 'nonce', false ) ) {
			wp_send_json_error( __( 'Invalid nonce', 'puckator-dropship-importer' ), 403 );
		}
		
		require_once PDI_PLUGIN_DIR . 'includes/class-pdi-helpers.php';
		
		if ( ! PDI_Helpers::check_rate_limit( 'search', 10, 60 ) ) {
			wp_send_json_error( __( 'Rate limit exceeded. Please wait before searching again.', 'puckator-dropship-importer' ), 429 );
		}
		
		$keyword = isset( $_POST['keyword'] ) ? sanitize_text_field( wp_unslash( $_POST['keyword'] ) ) : '';
		$keyword = mb_substr( $keyword, 0, 200 );
		
		$sku_only = ! empty( $_POST['sku_only'] ) && filter_var( wp_unslash( $_POST['sku_only'] ), FILTER_VALIDATE_BOOLEAN );
		
		require_once PDI_PLUGIN_DIR . 'includes/class-pdi-api.php';
		$feed = PDI_API::fetch_feed();
		
		if ( is_wp_error( $feed ) ) {
			PDI_Helpers::log( 'search_error', array( 'error' => $feed->get_error_message() ) );
			wp_send_json_error( $feed->get_error_message(), 500 );
		}
		
		$products = PDI_API::extract_products( $feed );
		
		if ( ! empty( $keyword ) ) {
			$products = PDI_Helpers::fuzzy_filter( $products, $keyword, $sku_only );
		}
		
		if ( empty( $products ) ) {
			wp_send_json_success( '<p>' . esc_html__( 'No results found.', 'puckator-dropship-importer' ) . '</p>' );
		}
		
		$products = array_slice( $products, 0, 500 );
		
		ob_start();
		PDI_Helpers::render_product_table( $products );
		$html = ob_get_clean();
		
		wp_send_json_success( $html );
	}

	/**
	 * AJAX import handler.
	 *
	 * @return void
	 */
	public function ajax_import() {
		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized', 'puckator-dropship-importer' ) ), 403 );
		}
		
		if ( ! check_ajax_referer( 'pdi_nonce', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid nonce', 'puckator-dropship-importer' ) ), 403 );
		}
		
		require_once PDI_PLUGIN_DIR . 'includes/class-pdi-helpers.php';
		
		if ( ! PDI_Helpers::check_rate_limit( 'import', 5, 60 ) ) {
			wp_send_json_error( array( 'message' => __( 'Rate limit exceeded. Please wait before trying again.', 'puckator-dropship-importer' ) ), 429 );
		}
		
		if ( ! class_exists( 'WC_Product' ) ) {
			wp_send_json_error( array( 'message' => __( 'WooCommerce is required.', 'puckator-dropship-importer' ) ), 400 );
		}
		
		$items_raw = array();
		
		// SECURE: Unslash and validate items array
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized in safe_decode_json_item method
		if ( isset( $_POST['items'] ) ) {
			$items_post = wp_unslash( $_POST['items'] );
			
			if ( is_array( $items_post ) ) {
				foreach ( $items_post as $raw_item ) {
					if ( is_string( $raw_item ) ) {
						$items_raw[] = $raw_item;
					}
				}
			}
		}
		// phpcs:enable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		
		if ( empty( $items_raw ) ) {
			wp_send_json_error( array( 'message' => __( 'No items selected.', 'puckator-dropship-importer' ) ), 400 );
		}
		
		if ( count( $items_raw ) > 200 ) {
			$items_raw = array_slice( $items_raw, 0, 200 );
		}
		
		$imported = 0;
		$errors   = array();
		
		$sku_cache = PDI_Helpers::get_all_store_skus();
		$use_cache = count( $sku_cache ) > 0;
		
		foreach ( $items_raw as $raw_json ) {
			// safe_decode_json_item sanitizes the data
			$item = PDI_Helpers::safe_decode_json_item( $raw_json );
			
			if ( is_wp_error( $item ) ) {
				$errors[] = $item->get_error_message();
				continue;
			}
			
			$sku_check = isset( $item['sku'] ) ? PDI_Helpers::sanitize_sku( (string) $item['sku'] ) : '';
			
			$exists = false;
			if ( ! empty( $sku_check ) ) {
				if ( $use_cache ) {
					$exists = isset( $sku_cache[ strtoupper( $sku_check ) ] );
				} else {
					$exists = (bool) wc_get_product_id_by_sku( $sku_check );
				}
			}
			
			if ( $exists ) {
				$errors[] = sprintf(
					/* translators: %s: SKU */
					__( 'SKU %s already imported, skipped.', 'puckator-dropship-importer' ),
					esc_html( $sku_check )
				);
				continue;
			}
			
			require_once PDI_PLUGIN_DIR . 'includes/class-pdi-sync.php';
			
			$reflection = new ReflectionClass( 'PDI_Sync' );
			$method     = $reflection->getMethod( 'create_or_update_wc_product' );
			$method->setAccessible( true );
			
			$result = $method->invoke( null, $item );
			
			if ( is_wp_error( $result ) ) {
				$errors[] = $result->get_error_message();
			} else {
				$imported++;
			}
		}
		
		if ( $imported > 0 ) {
			PDI_Helpers::log( 'import', array( 'count' => $imported ) );
			PDI_Helpers::log_security_event(
				'products_imported',
				array(
					'count'   => $imported,
					'user_id' => get_current_user_id(),
				)
			);
		}
		
		wp_send_json_success(
			array(
				'imported' => $imported,
				'errors'   => $errors,
			)
		);
	}

	/**
	 * AJAX manual sync handler.
	 *
	 * @return void
	 */
	public function ajax_manual_sync() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( __( 'Unauthorized', 'puckator-dropship-importer' ), 403 );
		}
		
		if ( ! check_ajax_referer( 'pdi_nonce', 'nonce', false ) ) {
			wp_send_json_error( __( 'Invalid nonce', 'puckator-dropship-importer' ), 403 );
		}
		
		require_once PDI_PLUGIN_DIR . 'includes/class-pdi-helpers.php';
		
		if ( ! PDI_Helpers::check_rate_limit( 'sync', 3, 300 ) ) {
			wp_send_json_error( __( 'Sync already running or rate limit exceeded. Please wait.', 'puckator-dropship-importer' ), 429 );
		}
		
		require_once PDI_PLUGIN_DIR . 'includes/class-pdi-sync.php';
		$result = PDI_Sync::sync_products();
		
		if ( is_wp_error( $result ) ) {
			status_header( 500 );
			echo '<div class="notice notice-error"><p>' . esc_html( $result->get_error_message() ) . '</p></div>';
		} else {
			PDI_Helpers::log_security_event(
				'manual_sync',
				array(
					'updated' => $result['updated'],
					'user_id' => get_current_user_id(),
				)
			);
			echo esc_html(
				sprintf(
					/* translators: %d: number of products */
					__( 'Synced %d product(s).', 'puckator-dropship-importer' ),
					intval( $result['updated'] )
				)
			);
		}
		
		wp_die();
	}
}