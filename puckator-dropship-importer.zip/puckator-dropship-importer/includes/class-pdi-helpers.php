<?php
/**
 * Helpers Class
 *
 * @package Puckator_Dropship_Importer
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Helper functions class.
 *
 * @since 3.5.0
 */
class PDI_Helpers {
	/**
	 * Get client IP address.
	 *
	 * @return string
	 */
	public static function get_client_ip() {
		$ip = '';
		
		$trusted_proxies = apply_filters( 'pdi_trusted_proxies', array() );
		if ( ! is_array( $trusted_proxies ) ) {
			$trusted_proxies = array();
		}
		
		// SECURE: Sanitize and unslash server variable.
		$remote_addr = isset( $_SERVER['REMOTE_ADDR'] ) ? 
			sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		
		if ( ! empty( $trusted_proxies ) && in_array( $remote_addr, $trusted_proxies, true ) ) {
			if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
				// SECURE: Sanitize and unslash forwarded IP.
				$forwarded = sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) );
				$ips       = array_map( 'trim', explode( ',', $forwarded ) );
				$ip        = isset( $ips[0] ) ? $ips[0] : '';
			}
		}
		
		if ( empty( $ip ) ) {
			$ip = $remote_addr;
		}
		
		$ip = trim( $ip );
		
		// SECURE: Validate IP format.
		if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return $ip;
		}
		
		return 'unknown';
	}

	/**
	 * Log security event.
	 *
	 * @param string $event Event name.
	 * @param array  $data Event data.
	 * @return void
	 */
	public static function log_security_event( $event, $data = array() ) {
		$user = wp_get_current_user();
		
		$security_log = array(
			'timestamp'  => current_time( 'mysql' ),
			'user_id'    => absint( $user->ID ),
			// SECURE: Sanitize user login.
			'user_login' => isset( $user->user_login ) ? sanitize_user( $user->user_login ) : 'unknown',
			'ip_address' => self::get_client_ip(),
			// SECURE: Sanitize event name.
			'event'      => sanitize_text_field( $event ),
			'data'       => self::sanitize_log_data( $data ),
		);

		$logs = get_option( PDI_Plugin::OPT_SECURITY_LOGS, array() );
		if ( ! is_array( $logs ) ) {
			$logs = array();
		}

		$logs[] = $security_log;
		$logs   = array_slice( $logs, - PDI_Plugin::SECURITY_LOG_CAP );
		
		update_option( PDI_Plugin::OPT_SECURITY_LOGS, $logs, false );
	}

	/**
	 * Check rate limit.
	 *
	 * @param string $action Action name.
	 * @param int    $limit Rate limit.
	 * @param int    $period Time period.
	 * @return bool
	 */
	public static function check_rate_limit( $action, $limit = 10, $period = 60 ) {
		// Allow administrators to bypass rate limits for manual sync.
		if ( 'sync' === $action && current_user_can( 'manage_options' ) ) {
			return true;
		}

		$user_id = get_current_user_id();
		$ip      = self::get_client_ip();
		
		// SECURE: Use WordPress hashing.
		$fingerprint = wp_hash( $user_id . '|' . $ip . '|' . wp_salt( 'auth' ), 'nonce' );
		
		// SECURE: Sanitize action for transient key.
		$action_safe = sanitize_key( $action );
		
		$user_key = 'pdi_ratelimit_' . $action_safe . '_user_' . absint( $user_id );
		$fp_key   = 'pdi_ratelimit_' . $action_safe . '_fp_' . sanitize_key( $fingerprint );
		
		$user_count = absint( get_transient( $user_key ) );
		$fp_count   = absint( get_transient( $fp_key ) );
		
		$limit  = absint( $limit );
		$period = absint( $period );
		
		if ( $user_count >= $limit || $fp_count >= $limit ) {
			$ban_key   = 'pdi_ban_' . $action_safe . '_' . sanitize_key( $fingerprint );
			$ban_count = absint( get_transient( $ban_key ) );
			
			self::log_security_event(
				'rate_limit_exceeded',
				array(
					'action'     => $action,
					'user_id'    => $user_id,
					'ip'         => $ip,
					'user_count' => $user_count,
					'fp_count'   => $fp_count,
					'ban_count'  => $ban_count,
				)
			);
			
			if ( $ban_count >= 3 ) {
				$ban_duration = min( DAY_IN_SECONDS, HOUR_IN_SECONDS * pow( 2, $ban_count - 3 ) );
				set_transient( $ban_key, $ban_count + 1, absint( $ban_duration ) );
				return false;
			}
			
			set_transient( $ban_key, $ban_count + 1, 5 * MINUTE_IN_SECONDS );
			return false;
		}
		
		set_transient( $user_key, $user_count + 1, $period );
		set_transient( $fp_key, $fp_count + 1, $period );
		
		return true;
	}

	/**
	 * Log event.
	 *
	 * @param string $action Action name.
	 * @param array  $data Event data.
	 * @return void
	 */
	public static function log( $action, $data = array() ) {
		$safe_data = self::sanitize_log_data( $data );
		
		$encoded = wp_json_encode( $safe_data );
		if ( is_string( $encoded ) && strlen( $encoded ) > 100000 ) {
			$safe_data = array( 'note' => 'Log entry truncated due to size' );
		}

		$logs = get_option( PDI_Plugin::OPT_LOGS, array() );
		if ( ! is_array( $logs ) ) {
			$logs = array();
		}
		
		$logs[] = array(
			'ts'     => time(),
			// SECURE: Sanitize action.
			'action' => sanitize_text_field( $action ),
			'data'   => $safe_data,
		);
		
		if ( count( $logs ) > PDI_Plugin::LOG_CAP ) {
			$logs = array_slice( $logs, - PDI_Plugin::LOG_CAP );
		}
		
		update_option( PDI_Plugin::OPT_LOGS, $logs, false );
	}

	/**
	 * Sanitize log data.
	 *
	 * @param array $data Log data.
	 * @return array
	 */
	public static function sanitize_log_data( $data ) {
		// SECURE: Re-encode to sanitize.
		$safe_data = json_decode( wp_json_encode( $data ), true );
		
		if ( ! is_array( $safe_data ) ) {
			return array();
		}
		
		$sensitive_keys = array( 'password', 'token', 'api_key', 'secret', 'auth', 'authorization', 'bearer' );
		
		// SECURE: Redact sensitive data.
		array_walk_recursive(
			$safe_data,
			function ( &$value, $key ) use ( $sensitive_keys ) {
				if ( in_array( strtolower( (string) $key ), $sensitive_keys, true ) ) {
					$value = '[REDACTED]';
				}
			}
		);
		
		return $safe_data;
	}

	/**
	 * Encrypt field.
	 *
	 * @param string $plain Plain text.
	 * @return string
	 * @throws Exception If encryption fails.
	 */
	public static function encrypt_field( $plain ) {
		if ( empty( $plain ) ) {
			return '';
		}
		
		// SECURE: Check for encryption key.
		if ( ! defined( 'AUTH_KEY' ) || empty( AUTH_KEY ) ) {
			throw new Exception( 'Encryption key not configured' );
		}
		
		// SECURE: Use strong hashing.
		$key   = hash( 'sha256', AUTH_KEY, true );
		$ivlen = openssl_cipher_iv_length( 'AES-256-CBC' );
		
		if ( false === $ivlen ) {
			throw new Exception( 'Invalid cipher' );
		}
		
		// SECURE: Generate random IV.
		$iv     = random_bytes( $ivlen );
		$cipher = openssl_encrypt( $plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
		
		if ( false === $cipher ) {
			throw new Exception( 'Encryption failed' );
		}
		
		// SECURE: Add HMAC for authentication.
		$hmac = hash_hmac( 'sha256', $iv . $cipher, $key, true );
		
		// SECURE: Use base64 encoding.
		return base64_encode( $hmac . $iv . $cipher ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Required for binary data
	}

	/**
	 * Decrypt field.
	 *
	 * @param string $encoded Encoded text.
	 * @return string
	 */
	public static function decrypt_field( $encoded ) {
		if ( empty( $encoded ) ) {
			return '';
		}
		
		if ( ! defined( 'AUTH_KEY' ) || empty( AUTH_KEY ) ) {
			return '';
		}
		
		// SECURE: Validate base64.
		$data = base64_decode( $encoded, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Required for encrypted data
		
		if ( false === $data || strlen( $data ) < 48 ) {
			return '';
		}
		
		$key = hash( 'sha256', AUTH_KEY, true );
		
		$hmac = substr( $data, 0, 32 );
		
		$ivlen = openssl_cipher_iv_length( 'AES-256-CBC' );
		
		if ( false === $ivlen || strlen( $data ) < ( 32 + $ivlen ) ) {
			return '';
		}
		
		$iv     = substr( $data, 32, $ivlen );
		$cipher = substr( $data, 32 + $ivlen );
		
		// SECURE: Verify HMAC.
		$expected_hmac = hash_hmac( 'sha256', $iv . $cipher, $key, true );
		
		if ( ! hash_equals( $expected_hmac, $hmac ) ) {
			return '';
		}
		
		$plain = openssl_decrypt( $cipher, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
		
		return is_string( $plain ) ? $plain : '';
	}

	/**
	 * Get settings.
	 *
	 * @return array
	 */
	public static function get_settings() {
		$defaults = array(
			'api_base'         => 'https://www.puckator-dropship.co.uk',
			'endpoint'         => PDI_Plugin::DEFAULT_ENDPOINT,
			'username'         => '',
			'password'         => '',
			'vat'              => '20.00',
			'paypal_percent'   => '2.90',
			'paypal_fixed'     => '0.30',
			'profit_percent'   => '20.00',
			'stock_field_path' => '',
			'price_field_key'  => '',
			'shipping_table'   => '[{"min":0,"max":0.1,"cost":2.49},{"min":0.1,"max":1,"cost":3.99},{"min":1,"max":1.5,"cost":4.99},{"min":1.5,"max":2,"cost":5.99}]',
		);
		
		$settings = get_option( PDI_Plugin::OPT_SETTINGS, array() );
		
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}
		
		$settings = wp_parse_args( $settings, $defaults );
		
		// SECURE: Normalize numeric values.
		foreach ( array( 'vat', 'paypal_percent', 'paypal_fixed', 'profit_percent' ) as $key ) {
			$settings[ $key ] = self::nf( $settings[ $key ] );
		}
		
		// SECURE: Decrypt password.
		if ( ! empty( $settings['password'] ) ) {
			$decrypted = self::decrypt_field( $settings['password'] );
			if ( ! empty( $decrypted ) ) {
				$settings['password'] = $decrypted;
			}
		}
		
		return $settings;
	}

	/**
	 * Validate password.
	 *
	 * @param string $password Password.
	 * @return true|WP_Error
	 */
	public static function validate_password( $password ) {
		// SECURE: Check length.
		if ( strlen( $password ) > 256 ) {
			return new WP_Error( 'password_too_long', __( 'Password is too long.', 'puckator-dropship-importer' ) );
		}
		
		if ( strlen( $password ) < 1 ) {
			return new WP_Error( 'password_empty', __( 'Password cannot be empty.', 'puckator-dropship-importer' ) );
		}
		
		// SECURE: Check for control characters.
		if ( preg_match( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $password ) ) {
			return new WP_Error( 'password_invalid_chars', __( 'Password contains invalid characters.', 'puckator-dropship-importer' ) );
		}
		
		// SECURE: Validate UTF-8.
		if ( ! mb_check_encoding( $password, 'UTF-8' ) ) {
			return new WP_Error( 'password_encoding', __( 'Password has invalid encoding.', 'puckator-dropship-importer' ) );
		}
		
		return true;
	}

	/**
	 * Validate numeric setting.
	 *
	 * @param mixed  $value Value.
	 * @param string $field Field name.
	 * @return float
	 */
	public static function validate_numeric_setting( $value, $field ) {
		// SECURE: Cast to float with sanitization.
		$val = (float) str_replace( ',', '.', (string) $value );
		
		// SECURE: Apply bounds based on field type.
		if ( in_array( $field, array( 'vat', 'paypal_percent', 'profit_percent' ), true ) ) {
			$val = max( 0.00, min( 100.00, $val ) );
		} else {
			$val = max( 0.00, min( 999999.99, $val ) );
		}
		
		return $val;
	}

	/**
	 * Validate shipping table.
	 *
	 * @param string $json JSON string.
	 * @return string|WP_Error
	 */
	public static function validate_shipping_table( $json ) {
		// SECURE: Decode with depth limit.
		$decoded = json_decode( $json, true, 32 );
		
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
			return new WP_Error( 'invalid_json', __( 'Shipping table must be valid JSON.', 'puckator-dropship-importer' ) );
		}
		
		$validated = array();
		
		foreach ( $decoded as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			
			// SECURE: Cast and validate numeric values.
			$min  = isset( $row['min'] ) ? (float) $row['min'] : 0.0;
			$max  = isset( $row['max'] ) ? (float) $row['max'] : 0.0;
			$cost = isset( $row['cost'] ) ? (float) $row['cost'] : 0.0;
			
			$min  = max( 0.0, min( 999999.99, $min ) );
			$max  = max( $min, min( 999999.99, $max ) );
			$cost = max( 0.0, min( 999999.99, $cost ) );
			
			$validated[] = array(
				'min'  => $min,
				'max'  => $max,
				'cost' => $cost,
			);
		}
		
		if ( empty( $validated ) ) {
			return new WP_Error( 'empty_table', __( 'Shipping table cannot be empty.', 'puckator-dropship-importer' ) );
		}
		
		return wp_json_encode( $validated );
	}

	/**
	 * Sanitize field path.
	 *
	 * @param string $path Field path.
	 * @return string
	 */
	public static function sanitize_field_path( $path ) {
		$path = trim( $path );
		
		if ( empty( $path ) ) {
			return '';
		}
		
		// SECURE: Remove unsafe characters.
		$path = preg_replace( '/[^a-z0-9_\.\-]/i', '', $path );
		// SECURE: Prevent path traversal.
		$path = str_replace( '..', '', $path );
		// SECURE: Limit length.
		$path = substr( $path, 0, 100 );
		
		return $path;
	}

	/**
	 * Sanitize SKU.
	 *
	 * @param string $sku SKU.
	 * @return string
	 */
	public static function sanitize_sku( $sku ) {
		// SECURE: Uppercase and trim.
		$sku = strtoupper( trim( $sku ) );
		
		// SECURE: Limit length.
		if ( strlen( $sku ) > 100 ) {
			$sku = substr( $sku, 0, 100 );
		}
		
		// SECURE: Allow only safe characters.
		if ( ! preg_match( '/^[A-Z0-9\-_]+$/i', $sku ) ) {
			return '';
		}
		
		return $sku;
	}

	/**
	 * Number format helper.
	 *
	 * @param mixed $value Value.
	 * @return string
	 */
	public static function nf( $value ) {
		// SECURE: Cast to float.
		$val = floatval( str_replace( ',', '.', (string) $value ) );
		return number_format( $val, 2, '.', '' );
	}

	/**
	 * Get all store SKUs.
	 *
	 * @return array
	 */
		/**
	 * Get all store SKUs.
	 *
	 * @return array
	 */
	public static function get_all_store_skus() {
		global $wpdb;
		
		$cache_version = get_transient( PDI_Plugin::CACHE_VERSION_TRANSIENT );
		if ( ! $cache_version ) {
			// SECURE: Generate unique cache version.
			$cache_version = wp_hash( time() . wp_rand(), 'nonce' );
			set_transient( PDI_Plugin::CACHE_VERSION_TRANSIENT, $cache_version, DAY_IN_SECONDS );
		}
		
		// SECURE: Hash cache key.
		$cache_key = 'pdi_skus_cache_' . wp_hash( $cache_version . get_current_blog_id(), 'nonce' );
		
		$cache = wp_cache_get( $cache_key, 'pdi' );
		if ( is_array( $cache ) && self::verify_cache_integrity( $cache ) ) {
			return $cache;
		}
		
		$cache = get_transient( $cache_key );
		if ( is_array( $cache ) && self::verify_cache_integrity( $cache ) ) {
			wp_cache_set( $cache_key, $cache, 'pdi', 5 * MINUTE_IN_SECONDS );
			return $cache;
		}
		
		$lock_key = 'pdi_sku_cache_building';
		if ( get_transient( $lock_key ) ) {
			sleep( 1 );
			$cache = get_transient( $cache_key );
			if ( is_array( $cache ) && self::verify_cache_integrity( $cache ) ) {
				wp_cache_set( $cache_key, $cache, 'pdi', 5 * MINUTE_IN_SECONDS );
				return $cache;
			}
		}
		
		set_transient( $lock_key, 1, 30 );
		
		try {
			// SECURE: Prepared statement.
			$query = $wpdb->prepare(
				"SELECT pm.meta_value FROM {$wpdb->postmeta} pm
				INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_key = %s AND p.post_type = %s
				LIMIT 50001",
				'_sku',
				'product'
			);
			
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$rows = $wpdb->get_col( $query ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Query is prepared above
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			
			// SECURE: Limit results.
			if ( count( $rows ) > 50000 ) {
				return array();
			}
			
			$out = array();
			if ( $rows ) {
				foreach ( $rows as $sku ) {
					// SECURE: Sanitize each SKU.
					$sku = strtoupper( trim( (string) $sku ) );
					if ( ! empty( $sku ) && strlen( $sku ) <= 100 && preg_match( '/^[A-Z0-9\-_]+$/i', $sku ) ) {
						$out[ $sku ] = true;
					}
				}
			}
			
			set_transient( $cache_key, $out, 5 * MINUTE_IN_SECONDS );
			wp_cache_set( $cache_key, $out, 'pdi', 5 * MINUTE_IN_SECONDS );
			
			return $out;
		} finally {
			delete_transient( $lock_key );
		}
	}

	/**
	 * Verify cache integrity.
	 *
	 * @param array $cache Cache data.
	 * @return bool
	 */
	private static function verify_cache_integrity( $cache ) {
		if ( empty( $cache ) ) {
			return true;
		}
		
		// SECURE: Limit cache size.
		if ( count( $cache ) > 50000 ) {
			return false;
		}
		
		// SECURE: Validate each SKU.
		foreach ( array_keys( $cache ) as $sku ) {
			if ( ! is_string( $sku ) || strlen( $sku ) > 100 ) {
				return false;
			}
			if ( ! preg_match( '/^[A-Z0-9\-_]+$/i', $sku ) ) {
				return false;
			}
		}
		
		return true;
	}

	/**
	 * Invalidate SKU cache.
	 *
	 * @return void
	 */
	public static function invalidate_sku_cache() {
		$cache_version = get_transient( PDI_Plugin::CACHE_VERSION_TRANSIENT );
		if ( $cache_version ) {
			$cache_key = 'pdi_skus_cache_' . wp_hash( $cache_version . get_current_blog_id(), 'nonce' );
			delete_transient( $cache_key );
			wp_cache_delete( $cache_key, 'pdi' );
		}
	}

	/**
	 * Safe decode JSON item.
	 *
	 * @param mixed $raw Raw data.
	 * @param int   $max_len Maximum length.
	 * @return array|WP_Error
	 */
		/**
	 * Safe decode JSON item.
	 *
	 * @param mixed $raw Raw data.
	 * @param int   $max_len Maximum length.
	 * @return array|WP_Error
	 */
	public static function safe_decode_json_item( $raw, $max_len = 65536 ) {
		// SECURE: Validate type.
		if ( ! is_string( $raw ) ) {
			return new WP_Error( 'bad_item', __( 'Invalid item type', 'puckator-dropship-importer' ) );
		}
		
		// SECURE: Remove slashes.
		$raw = wp_unslash( $raw );
		
		// SECURE: Validate UTF-8.
		if ( ! mb_check_encoding( $raw, 'UTF-8' ) ) {
			return new WP_Error( 'bad_utf8', __( 'Invalid UTF-8 encoding', 'puckator-dropship-importer' ) );
		}
		
		// SECURE: Check size.
		$max_len = absint( $max_len );
		if ( strlen( $raw ) > $max_len ) {
			return new WP_Error( 'too_big', __( 'Item exceeds maximum size', 'puckator-dropship-importer' ) );
		}
		
		// SECURE: Decode with depth limit.
		$decoded = json_decode( $raw, true, 32 );
		
		if ( JSON_ERROR_NONE !== json_last_error() ) {
			return new WP_Error(
				'bad_json',
				sprintf(
					/* translators: %s: JSON error message */
					__( 'Invalid JSON: %s', 'puckator-dropship-importer' ),
					json_last_error_msg()
				)
			);
		}
		
		// SECURE: Validate result type.
		if ( ! is_array( $decoded ) ) {
			return new WP_Error( 'bad_json', __( 'Invalid item payload - must be array', 'puckator-dropship-importer' ) );
		}
		
		return $decoded;
	}

	/**
	 * Get value by path.
	 *
	 * @param array  $data Data array.
	 * @param string $path Path.
	 * @return mixed
	 */
	public static function get_by_path( $data, $path ) {
		$path = trim( $path );
		if ( empty( $path ) ) {
			return null;
		}
		
		// SECURE: Parse path safely.
		$parts = array_values(
			array_filter(
				explode( '.', $path ),
				function ( $p ) {
					return ! empty( $p );
				}
			)
		);
		
		// SECURE: Limit depth.
		if ( empty( $parts ) || count( $parts ) > 12 ) {
			return null;
		}
		
		$cursor = $data;
		foreach ( $parts as $seg ) {
			// SECURE: Prevent path traversal.
			if ( '.' === $seg || '..' === $seg || false !== strpos( $seg, '/' ) || false !== strpos( $seg, '\\' ) ) {
				return null;
			}
			
			if ( is_array( $cursor ) && array_key_exists( $seg, $cursor ) ) {
				$cursor = $cursor[ $seg ];
			} else {
				return null;
			}
		}
		
		return $cursor;
	}

	/**
	 * Extract price from product data.
	 *
	 * @param array $product Product data.
	 * @return float
	 */
	public static function extract_price( $product ) {
		$settings = self::get_settings();
		$keys     = array();
		
		if ( ! empty( $settings['price_field_key'] ) ) {
			$keys[] = $settings['price_field_key'];
		}
		
		$keys = array_merge(
			$keys,
			array(
				'price',
				'cost',
				'price_ex_vat',
				'price_inc_vat',
				'base_price',
				'supplier_price',
			)
		);
		
		foreach ( $keys as $key ) {
			$val = self::get_by_path( $product, $key );
			// SECURE: Validate numeric.
			if ( is_numeric( $val ) ) {
				return max( 0.0, (float) $val );
			}
		}
		
		return 0.0;
	}

	/**
	 * Extract stock from product data.
	 *
	 * @param array $product Product data.
	 * @return int
	 */
	public static function extract_stock( $product ) {
		$settings = self::get_settings();

		if ( ! empty( $settings['stock_field_path'] ) ) {
			$val = self::get_by_path( $product, $settings['stock_field_path'] );
			if ( is_numeric( $val ) ) {
				return max( 0, (int) $val );
			}
		}

		foreach ( array( 'qty', 'stock', 'stock_qty', 'quantity', 'qty_available', 'available' ) as $key ) {
			if ( isset( $product[ $key ] ) && is_numeric( $product[ $key ] ) ) {
				return max( 0, (int) $product[ $key ] );
			}
		}

		$found = self::find_numeric_key_recursive( $product, array( 'qty', 'stock', 'quantity' ) );
		if ( null !== $found ) {
			return max( 0, (int) $found );
		}

		foreach ( array( 'in_stock', 'is_in_stock', 'stock_status' ) as $key ) {
			$val = self::get_by_path( $product, $key );
			if ( is_bool( $val ) ) {
				return $val ? 1 : 0;
			}
			if ( is_string( $val ) ) {
				$vl = strtolower( $val );
				if ( in_array( $vl, array( 'in_stock', 'instock', 'yes', 'true', '1' ), true ) ) {
					return 1;
				}
				if ( in_array( $vl, array( 'out_of_stock', 'outofstock', 'no', 'false', '0' ), true ) ) {
					return 0;
				}
			}
		}

		return 0;
	}

	/**
	 * Find numeric key recursively.
	 *
	 * @param mixed $array Array to search.
	 * @param array $keywords Keywords.
	 * @return mixed
	 */
	private static function find_numeric_key_recursive( $array, $keywords ) {
		if ( ! is_array( $array ) ) {
			return null;
		}
		
		foreach ( $array as $key => $value ) {
			if ( is_array( $value ) ) {
				$result = self::find_numeric_key_recursive( $value, $keywords );
				if ( null !== $result ) {
					return $result;
				}
			} else {
				foreach ( $keywords as $word ) {
					// SECURE: Cast key to string.
					if ( false !== stripos( (string) $key, $word ) && is_numeric( $value ) ) {
						return $value;
					}
				}
			}
		}
		
		return null;
	}

	/**
	 * Extract weight from product data.
	 *
	 * @param array $product Product data.
	 * @return float
	 */
	public static function extract_weight( $product ) {
		foreach ( array(
			'weight',
			'package_weight',
			'product_weight',
			'shipping_weight',
			'extension_attributes.weight',
		) as $key ) {
			$val = self::get_by_path( $product, $key );
			if ( is_numeric( $val ) ) {
				return max( 0.0, (float) $val );
			}
		}
		
		return 0.0;
	}

	/**
	 * Get shipping cost for weight.
	 *
	 * @param float $weight Weight.
	 * @return float
	 */
	public static function get_shipping_for_weight( $weight ) {
		$settings = self::get_settings();
		// SECURE: Decode with depth limit.
		$table    = json_decode( $settings['shipping_table'] ?? '', true, 32 );

		if ( ! is_array( $table ) || empty( $table ) ) {
			return 0.00;
		}

		// SECURE: Validate weight.
		$weight = max( 0.0, (float) $weight );

		foreach ( $table as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			
			// SECURE: Cast to float.
			$min  = isset( $row['min'] ) ? max( 0.0, (float) $row['min'] ) : 0.0;
			$max  = isset( $row['max'] ) ? max( 0.0, (float) $row['max'] ) : 0.0;
			$cost = isset( $row['cost'] ) ? max( 0.0, (float) $row['cost'] ) : 0.0;
			
			if ( $weight >= $min && $weight <= $max ) {
				return $cost;
			}
		}

		$last = end( $table );
		return isset( $last['cost'] ) ? max( 0.0, (float) $last['cost'] ) : 0.00;
	}

	/**
	 * Fuzzy filter products.
	 *
	 * @param array  $products Products.
	 * @param string $keyword Keyword.
	 * @param bool   $sku_only SKU only search.
	 * @return array
	 */
	public static function fuzzy_filter( $products, $keyword, $sku_only ) {
		// SECURE: Limit array size.
		if ( count( $products ) > 5000 ) {
			$products = array_slice( $products, 0, 5000 );
		}

		$kw_norm = self::norm( $keyword );

		if ( $sku_only ) {
			$exact = strtolower( trim( $kw_norm ) );
			$out   = array();

			foreach ( $products as $product ) {
				// SECURE: Sanitize SKU.
				$sku = strtolower( trim( (string) ( $product['sku'] ?? '' ) ) );
				if ( ! empty( $sku ) && $sku === $exact ) {
					$out[] = $product;
				}
			}

			return $out;
		}

		$threshold = 0.30;
		$scored    = array();

		foreach ( $products as $product ) {
			// SECURE: Sanitize fields.
			$fields = array(
				sanitize_text_field( $product['name'] ?? '' ),
				sanitize_text_field( $product['title'] ?? '' ),
				sanitize_text_field( $product['sku'] ?? '' ),
				wp_strip_all_tags( $product['description'] ?? '' ),
			);

			$hay   = implode( ' ', array_map( 'trim', array_filter( $fields ) ) );
			$score = self::fuzzy_score_adv( $hay, $keyword );

			if ( $score >= $threshold ) {
				$scored[] = array(
					'score' => $score,
					'p'     => $product,
				);
			}
		}

		usort(
			$scored,
			function ( $a, $b ) {
				return $b['score'] <=> $a['score'];
			}
		);

		return array_map(
			function ( $entry ) {
				return $entry['p'];
			},
			$scored
		);
	}

	/**
	 * Normalize string.
	 *
	 * @param string $string String.
	 * @return string
	 */
	private static function norm( $string ) {
		$string = strtolower( (string) $string );
		
		if ( function_exists( 'transliterator_transliterate' ) ) {
			$transliterated = transliterator_transliterate( 'Any-Latin; Latin-ASCII', $string );
			if ( false !== $transliterated ) {
				$string = $transliterated;
			}
		}
		
		// SECURE: Remove unsafe characters.
		$string = preg_replace( '/[^a-z0-9\s]/', ' ', $string );
		$string = preg_replace( '/\s+/', ' ', $string );
		
		return trim( $string );
	}

	/**
	 * Get tokens from string.
	 *
	 * @param string $string String.
	 * @return array
	 */
	private static function tokens( $string ) {
		$normalized = self::norm( $string );
		return $normalized ? array_values( array_filter( explode( ' ', $normalized ) ) ) : array();
	}

	/**
	 * Get trigrams from string.
	 *
	 * @param string $string String.
	 * @return array
	 */
	private static function trigrams( $string ) {
		$string = '  ' . $string . '  ';
		$out    = array();
		$len    = strlen( $string );
		
		for ( $i = 0; $i < $len - 2; $i++ ) {
			$out[] = substr( $string, $i, 3 );
		}
		
		return array_values( array_unique( $out ) );
	}

	/**
	 * Advanced fuzzy score.
	 *
	 * @param string $hay Haystack.
	 * @param string $query Query.
	 * @return float
	 */
	private static function fuzzy_score_adv( $hay, $query ) {
		$h = self::norm( $hay );
		$q = self::norm( $query );

		if ( empty( $h ) || empty( $q ) ) {
			return 0.0;
		}

		if ( false !== strpos( $h, $q ) ) {
			return 1.0;
		}

		$ht = self::tokens( $h );
		$qt = self::tokens( $q );

		if ( empty( $ht ) || empty( $qt ) ) {
			return 0.0;
		}

		$covered = 0;
		foreach ( $qt as $qtok ) {
			$hit = false;
			foreach ( $ht as $htok ) {
				if ( $htok === $qtok || false !== strpos( $htok, $qtok ) ) {
					$hit = true;
					break;
				}
				// SECURE: Limit string lengths for levenshtein.
				if ( strlen( $htok ) <= 255 && strlen( $qtok ) <= 255 ) {
					$dist = levenshtein( $htok, $qtok );
					$len  = max( strlen( $qtok ), 1 );
					if ( $dist <= ceil( $len / 4 ) ) {
						$hit = true;
						break;
					}
				}
			}
			if ( $hit ) {
				$covered++;
			}
		}

		$coverage = count( $qt ) ? ( $covered / count( $qt ) ) : 0.0;

		$hg = self::trigrams( $h );
		$qg = self::trigrams( $q );

		$inter = array_intersect( $hg, $qg );
		$union = array_unique( array_merge( $hg, $qg ) );

		$tri = count( $union ) > 0 ? count( $inter ) / count( $union ) : 0.0;

		$partial_hits = 0;
		foreach ( $qt as $word ) {
			foreach ( $ht as $hword ) {
				if ( substr_count( $hword, $word ) > 0 ) {
					$partial_hits++;
					break;
				}
			}
		}
		$partial_score = count( $qt ) ? min( 1.0, $partial_hits / count( $qt ) ) : 0.0;

		$score = ( 0.55 * $coverage ) + ( 0.30 * $tri ) + ( 0.15 * $partial_score );

		return max( 0.0, min( 1.0, $score ) );
	}

	/**
	 * Get allowed log HTML.
	 *
	 * @return array
	 */
	public static function get_allowed_log_html() {
		return array(
			'p'       => array( 'class' => array(), 'style' => array() ),
			'div'     => array( 'class' => array() ),
			'span'    => array( 'class' => array() ),
			'strong'  => array(),
			'em'      => array(),
			'details' => array( 'open' => array() ),
			'summary' => array(),
			'table'   => array( 'class' => array() ),
			'thead'   => array(),
			'tbody'   => array(),
			'tr'      => array(),
			'th'      => array(),
			'td'      => array(),
			'pre'     => array(),
		);
	}

	/**
	 * Format log summary.
	 *
	 * @param array $data Log data.
	 * @return string
	 */
		/**
	 * Format log summary.
	 *
	 * @param array $data Log data.
	 * @return string
	 */
	public static function format_log_summary( $data ) {
		$summary = '';
		
		if ( isset( $data['updated'] ) ) {
			$summary .= '<p>✅ ' . sprintf(
				/* translators: %d: number of products updated */
				esc_html__( 'Updated %d products.', 'puckator-dropship-importer' ),
				absint( $data['updated'] )
			) . '</p>';
		}
		
		if ( isset( $data['count'] ) ) {
			$summary .= '<p>✅ ' . sprintf(
				/* translators: %d: number of products imported */
				esc_html__( 'Imported %d products.', 'puckator-dropship-importer' ),
				absint( $data['count'] )
			) . '</p>';
		}
		
		if ( isset( $data['message'] ) ) {
			// SECURE: Escape message.
			$summary .= '<p>⚙️ ' . esc_html( $data['message'] ) . '</p>';
		}
		
		if ( isset( $data['note'] ) ) {
			// SECURE: Escape note.
			$summary .= '<p class="pdi-note">' . esc_html( $data['note'] ) . '</p>';
		}
		
		if ( isset( $data['error'] ) ) {
			// SECURE: Escape error.
			$summary .= '<p style="color:#b30000;">❌ ' . esc_html( $data['error'] ) . '</p>';
		}
		
		if ( ! empty( $data['details'] ) && is_array( $data['details'] ) ) {
			$summary .= self::format_log_details( $data['details'] );
		}
		
		if ( empty( $summary ) && ! empty( $data ) ) {
			$pretty = wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
			// SECURE: Escape JSON.
			$summary = '<pre>' . esc_html( $pretty ) . '</pre>';
		}
		
		return $summary;
	}

	/**
	 * Format log details.
	 *
	 * @param array $details Log details.
	 * @return string
	 */
	private static function format_log_details( $details ) {
		$html  = '<details><summary>' . esc_html__( 'Show Details', 'puckator-dropship-importer' ) . '</summary>';
		$html .= '<table class="pdi-detail-table"><thead><tr>';
		$html .= '<th>' . esc_html__( 'Product ID', 'puckator-dropship-importer' ) . '</th>';
		$html .= '<th>' . esc_html__( 'SKU', 'puckator-dropship-importer' ) . '</th>';
		$html .= '<th>' . esc_html__( 'Changes', 'puckator-dropship-importer' ) . '</th>';
		$html .= '</tr></thead><tbody>';
		
		foreach ( $details as $detail ) {
			// SECURE: Escape all output.
			$pid     = esc_html( $detail['product_id'] ?? '' );
			$sku     = esc_html( $detail['sku'] ?? '' );
			$changes = '';
			
			if ( isset( $detail['changed'] ) && is_array( $detail['changed'] ) ) {
				foreach ( $detail['changed'] as $field => $vals ) {
					// SECURE: Escape field values.
					$field_safe = esc_html( ucfirst( (string) $field ) );
					$from       = isset( $vals['from'] ) ? esc_html( $vals['from'] ) : '';
					$to         = isset( $vals['to'] ) ? esc_html( $vals['to'] ) : '';
					$changes   .= '<div>' . $field_safe . ': ' . $from . ' → ' . $to . '</div>';
				}
			}
			
			if ( empty( $changes ) ) {
				$changes = '<span class="pdi-note">' . esc_html__( 'No details', 'puckator-dropship-importer' ) . '</span>';
			}
			
			$html .= '<tr><td>' . $pid . '</td><td>' . $sku . '</td><td>' . $changes . '</td></tr>';
		}
		
		$html .= '</tbody></table></details>';
		
		return $html;
	}

	/**
	 * Render product table.
	 *
	 * @param array $products Products.
	 * @return void
	 */
	public static function render_product_table( $products ) {
		$existing = self::get_all_store_skus();
		$settings = self::get_settings();
		
		echo '<table class="widefat striped">';
		echo '<thead><tr>';
		echo '<th></th>';
		echo '<th>' . esc_html__( 'SKU', 'puckator-dropship-importer' ) . '</th>';
		echo '<th>' . esc_html__( 'Name', 'puckator-dropship-importer' ) . '</th>';
		echo '<th>' . esc_html__( 'Price (£)', 'puckator-dropship-importer' ) . '</th>';
		echo '<th>' . esc_html__( 'Weight (kg)', 'puckator-dropship-importer' ) . '</th>';
		echo '<th>' . esc_html__( 'Stock', 'puckator-dropship-importer' ) . '</th>';
		echo '<th>' . esc_html__( 'Breakdown', 'puckator-dropship-importer' ) . '</th>';
		echo '</tr></thead><tbody>';
		
		foreach ( $products as $product ) {
			// SECURE: Sanitize all product data.
			$sku    = self::sanitize_sku( $product['sku'] ?? '' );
			$name   = sanitize_text_field( substr( (string) ( $product['name'] ?? ( $product['title'] ?? '' ) ), 0, 200 ) );
			$price  = (float) self::extract_price( $product );
			$weight = (float) self::extract_weight( $product );
			$qty    = (int) self::extract_stock( $product );
			$ship   = (float) self::get_shipping_for_weight( $weight );
			
			$base     = $price + $ship;
			$vat      = $base * ( (float) $settings['vat'] / 100 );
			$paypal   = (float) $settings['paypal_fixed'] + $base * ( (float) $settings['paypal_percent'] / 100 );
			$subtotal = $base + $vat + $paypal;
			$final    = max( 0, round( $subtotal * ( 1 + ( (float) $settings['profit_percent'] / 100 ) ), 2 ) );
			$profit   = $final - $subtotal;
			
			// SECURE: All numeric values are already floats.
			$price_f   = number_format( $price, 2 );
			$ship_f    = number_format( $ship, 2 );
			$vat_f     = number_format( $vat, 2 );
			$paypal_f  = number_format( $paypal, 2 );
			$profit_f  = number_format( $profit, 2 );
			$final_f   = number_format( $final, 2 );
			$weight_f  = number_format( $weight, 2 );
			
			$imported  = isset( $existing[ strtoupper( $sku ) ] );
			$row_class = $imported ? 'pdi-row-imported' : '';
			
			// SECURE: Sanitize description for JSON.
			$description = isset( $product['description'] ) ? 
				sanitize_textarea_field( wp_strip_all_tags( $product['description'] ) ) : '';
			
			$minimized = array(
				'sku'         => $sku,
				'name'        => $name,
				'title'       => isset( $product['title'] ) ? 
					sanitize_text_field( substr( (string) $product['title'], 0, 200 ) ) : '',
				'description' => $description,
				'price'       => $price,
				'weight'      => $weight,
				'qty'         => $qty,
			);
			
			// Build the row HTML.
			?>
			<tr class="<?php echo esc_attr( $row_class ); ?>">
				<td>
					<input type="checkbox" class="pdi-item" data-item="<?php echo esc_attr( wp_json_encode( $minimized, JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_HEX_TAG ) ); ?>"<?php disabled( $imported ); ?>>
				</td>
				<td>
					<?php echo esc_html( $sku ); ?>
					<?php if ( $imported ) : ?>
						<span class="pdi-badge-imported"><?php esc_html_e( 'Imported', 'puckator-dropship-importer' ); ?></span>
					<?php endif; ?>
				</td>
				<td><?php echo esc_html( $name ); ?></td>
				<td>£<?php echo esc_html( $final_f ); ?></td>
				<td><?php echo esc_html( $weight_f ); ?></td>
				<td><?php echo esc_html( $qty ); ?></td>
				<td>
					<small>
						<?php
						echo esc_html__( 'Cost: £', 'puckator-dropship-importer' ) . esc_html( $price_f ) . ' | ';
						echo esc_html__( 'Ship: £', 'puckator-dropship-importer' ) . esc_html( $ship_f ) . ' | ';
						echo esc_html__( 'VAT: £', 'puckator-dropship-importer' ) . esc_html( $vat_f ) . ' | ';
						echo esc_html__( 'PayPal: £', 'puckator-dropship-importer' ) . esc_html( $paypal_f ) . ' | ';
						echo esc_html__( 'Profit: £', 'puckator-dropship-importer' ) . esc_html( $profit_f );
						?>
					</small>
				</td>
			</tr>
			<?php
		}
		
		echo '</tbody></table>';
		echo '<p><button id="pdi-import-selected" class="button button-primary">' . esc_html__( 'Import Selected', 'puckator-dropship-importer' ) . '</button></p>';
	}
}