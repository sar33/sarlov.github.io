=== Puckator Dropship Importer ===
Contributors: sar33
Tags: woocommerce, dropship, import, puckator, products
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 3.5.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Import Puckator products into WooCommerce with secure API authentication, fuzzy search, dynamic pricing, and automated daily sync.

== Description ==

Puckator Dropship Importer seamlessly integrates Puckator's dropshipping products into your WooCommerce store with advanced features:

= Key Features =

* **Secure API Integration**: Connect to Puckator's API with encrypted password storage using AES-256-CBC
* **Smart Product Search**: Fuzzy keyword and SKU-based search with advanced matching algorithms
* **Dynamic Pricing Calculator**: Automatically calculates final prices including:
  * Base product cost
  * Weight-based shipping costs
  * VAT percentage
  * PayPal fees (fixed + percentage)
  * Your profit margin
* **Automated Daily Sync**: Keeps product prices and stock levels up-to-date at 06:00 daily
* **Manual Sync**: On-demand synchronization with progress tracking
* **Bulk Import**: Select and import multiple products at once
* **Security Features**:
  * Rate limiting to prevent abuse
  * IP-based request tracking
  * Security event logging
  * HTTPS-only API connections
  * Input validation and sanitization
* **Comprehensive Logging**: Track all imports, syncs, and system events
* **Already Imported Detection**: Prevents duplicate imports

= Requirements =

* WordPress 6.0 or higher
* WooCommerce 5.0 or higher
* PHP 7.4 or higher
* Valid Puckator API credentials
* HTTPS enabled site

= How It Works =

1. Configure your Puckator API credentials in Settings
2. Set your pricing parameters (VAT, PayPal fees, profit margin)
3. Configure weight-based shipping costs
4. Search for products by keyword or SKU
5. Select products and import them
6. Daily sync keeps everything updated automatically

= Privacy & Security =

* Passwords are encrypted using WordPress AUTH_KEY
* All API requests use HTTPS
* Rate limiting prevents abuse
* Security events are logged
* No data is sent to third parties

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/puckator-dropship-importer/`
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Navigate to Puckator → Settings
4. Enter your Puckator API credentials
5. Configure your pricing parameters
6. Start importing products!

= Manual Installation =

1. Download the plugin ZIP file
2. Go to WordPress Admin → Plugins → Add New
3. Click "Upload Plugin"
4. Choose the ZIP file and click "Install Now"
5. Activate the plugin
6. Configure settings as above

== Frequently Asked Questions ==

= Do I need a Puckator account? =

Yes, you need valid Puckator API credentials to use this plugin.

= How often does the sync run? =

The automated sync runs daily at 06:00 in your site's timezone. You can also run manual syncs anytime.

= What happens if a product already exists? =

The plugin detects existing products by SKU and prevents duplicate imports. During sync, existing products are updated with current prices and stock levels.

= Can I customize the pricing formula? =

Yes! You can configure:
* VAT percentage
* PayPal fixed fee
* PayPal percentage fee
* Your profit margin percentage
* Weight-based shipping costs (JSON table)

= Is my API password secure? =

Yes, passwords are encrypted using AES-256-CBC with HMAC authentication before being stored in the database.

= Can I import products in bulk? =

Yes, you can search for products and select multiple items to import at once (up to 200 products per batch).

= What if the sync gets stuck? =

Administrators can manually clear the sync lock from the Dashboard page.

== Screenshots ==

1. Dashboard - View sync status and schedule
2. Settings - Configure API and pricing parameters
3. Search & Import - Find and import products
4. Logs - Track all plugin activity

== Changelog ==

= 3.5.0 - 2025-01-26 =
* Complete rewrite for WordPress Plugin Check compliance
* Separated code into modular class structure
* Added comprehensive security features
* Improved rate limiting with fingerprinting
* Enhanced logging with security events
* Added PHPCS compliance
* Improved i18n/l10n support
* Better error handling
* Performance optimizations
* UI improvements

= 3.4.2 - 2025-01-26 =
* Fixed sync rate limiting for administrators
* Added sync lock status display
* Added manual sync lock clearing
* Improved error messages

= 3.4.0 - 2025-01-26 =
* Added fuzzy search with trigram matching
* Improved pricing breakdown display
* Enhanced security with encrypted passwords
* Added comprehensive logging
* Better error handling

= 3.0.0 - 2025-01-25 =
* Initial public release
* Core functionality implemented

== Upgrade Notice ==

= 3.5.0 =
Major update with improved security, performance, and WordPress standards compliance. Recommended for all users.

== Additional Info ==

= Support =

For support, please visit: https://github.com/sar33/puckator-dropship-importer/issues

= Contributing =

Contributions are welcome! Visit: https://github.com/sar33/puckator-dropship-importer

= Credits =

Developed by sar33

== Technical Details ==

= API Integration =

The plugin connects to Puckator's REST API using:
* Bearer token authentication
* JSON data format
* HTTPS-only connections
* Response size limiting
* Feed caching (10 minutes)

= Database =

The plugin stores:
* Settings (encrypted passwords)
* Activity logs (capped at 800 entries)
* Security logs (capped at 500 entries)
* Transient caches for SKUs and API tokens

No custom database tables are created.

= Cron Jobs =

A single daily cron job runs at 06:00 (site timezone) to sync products.

= Performance =

* Batched database queries
* Memory-aware batch sizing
* Object caching support
* Transient caching
* Efficient SKU lookups

= Security Features =

* Rate limiting with exponential backoff
* IP-based fingerprinting
* Nonce verification on all AJAX requests
* Capability checks
* Input sanitization and validation
* Output escaping
* HTTPS enforcement
* Security headers
* Event logging