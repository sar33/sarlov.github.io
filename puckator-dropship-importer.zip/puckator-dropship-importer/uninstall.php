<?php
/**
 * Uninstall Script
 *
 * @package Puckator_Dropship_Importer
 */

// Exit if accessed directly or not uninstalling.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// SECURE: Delete plugin options.
delete_option( 'pdi_settings_v30' );
delete_option( 'pdi_logs_v30' );
delete_option( 'pdi_security_logs_v32' );

// SECURE: Delete transients.
delete_transient( 'pdi_token_v30' );
delete_transient( 'pdi_cache_version_v32' );
delete_transient( 'pdi_feed_cache' );

// SECURE: Delete all plugin transients using prepared statement.
global $wpdb;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
		$wpdb->esc_like( '_transient_pdi_' ) . '%',
		$wpdb->esc_like( '_transient_timeout_pdi_' ) . '%'
	)
);
// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

// SECURE: Clear scheduled cron jobs.
wp_clear_scheduled_hook( 'pdi_daily_sync_v30' );

// Optional: Delete product meta (uncomment if you want to remove all traces).
/*
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->postmeta} WHERE meta_key IN (%s, %s)",
		'_pdi_source_v30',
		'_pdi_sku_v30'
	)
);
// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
*/